from app import create_app
from app.config import Config

app = create_app()

if __name__ == '__main__':
    # WebAuthn strictly requires localhost or HTTPS
    print(f"Starting VeilPay on {Config.ORIGIN} (RP_ID: {Config.RP_ID})...")
    app.run(host='127.0.0.1', port=5000, debug=False)

