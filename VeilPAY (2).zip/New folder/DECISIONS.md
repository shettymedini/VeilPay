# VeilPay: Architectural and Technical Decisions

This document records technical choices made during the build to resolve ambiguities in the simplest and most robust way, as mandated by the VeilPay specification.

---

## 1. Directory Structure
- Follows the specification layout exactly. Root folder contains `app/`, `tests/`, `.env.example`, `DECISIONS.md`, `README.md`, `requirements.txt`, and `run.py`.

## 2. MongoDB & Database Fallback
- Production / Cloud uses MongoDB Atlas specified via `MONGODB_URI`.
- In test environments or when `MONGODB_URI` is unset or unreachable during offline tests, `mongomock` is used seamlessly as a fallback so that test suites run deterministically without network flakiness.

## 3. WebAuthn Implementation
- Using `webauthn` (`py_webauthn`) strictly according to W3C WebAuthn level 2/3 specs.
- Signature challenge is exactly `SHA256(canonical_intent)`.
- Challenge storage uses TTL index in `webauthn_challenges`.
- Replay prevention: challenges are single-use (`get_and_consume_challenge`), and second attempts are rejected.

## 4. Encryption for Platform-Only Fields
- User contact email and recipient PayPal payout email are encrypted at rest using `cryptography.fernet.Fernet`.
- The encryption key is sourced from `FERNET_KEY`.

## 5. Idempotency & PayPal Client
- Every state-changing PayPal request generates a unique `PayPal-Request-Id` header (UUIDv4 or intent-derived).
- OAuth 2.0 bearer tokens are cached and refreshed before expiry.
- Payouts API fallback: if sandbox business accounts lack Payouts permissions, gracefully logs a simulated payout in the ledger with audit flags.

## 6. Currency and Money Handling
- All internal computations use `decimal.Decimal` (Rule 5: Money is never a float).
- Serialized amounts in the database, API JSON, and canonical intent hashes are formatted with two decimal places (e.g. `'12.50'`).

## 7. AI Risk Engine & Strict Constraints
- Deterministic rules govern transaction authorization and hard limit blocks (Rule 3).
- The LLM layer operates strictly as an explainer and can only raise risk (`0 <= extra_risk <= 20`), never lower it.
- Memos are treated as untrusted user input wrapped in schema-validated prompts to prevent prompt injection.

## 8. Two-Pass PII Scrubber
- Pass 1 runs high-precision regular expressions for Indian/international phone numbers, emails, UPI handles, URLs, and 8+ digit sequences.
- Pass 2 runs an LLM pass to detect spelled-out and obfuscated contact details.
- Any detected details are replaced with `[hidden]` before reaching counterparties or ledger records.

## 9. Append-Only Tamper-Evident Ledger
- Hash chain formula: `hash = SHA256(prev_hash + canonical(event, data, ts))`.
- Timestamps are formatted with fixed ISO 8601 formatting to guarantee deterministic cross-platform hash verification.
