import datetime
from decimal import Decimal
import pytest
from bson import ObjectId
from app import create_app
from app.db import get_db
from app.risk.engine import evaluate_risk, get_risk_tier
from app.risk.llm import generate_risk_explanation

@pytest.fixture
def db():
    return get_db(force_mock=True)

def create_mock_user(db, alias, limits=None, cooling_hours=24):
    user = {
        "_id": ObjectId(),
        "alias": alias,
        "limits": limits or {
            "per_payment": "200.00",
            "per_day": "500.00",
            "per_payee_default": "100.00"
        },
        "new_payee_cooling_hours": cooling_hours,
        "status": "active"
    }
    db.users.insert_one(user)
    return user

def test_hard_limits_block_payments(db):
    """
    Acceptance criteria (Section 11):
    - Hard rules (BLOCKED, no override):
      - Amount > per_payment limit
      - Amount > per_payee limit
      - Daily total > per_day limit
    """
    payer = create_mock_user(db, "veil-payer1")
    payee = create_mock_user(db, "veil-payee1")

    # 1. Exceeds per_payment limit ($200.00)
    risk_res = evaluate_risk(db, payer, payee, amount_dec=Decimal("250.00"))
    assert risk_res["is_blocked"] is True
    assert "per-payment" in risk_res["block_reason"]

    # 2. Exceeds default per_payee limit ($100.00)
    risk_payee = evaluate_risk(db, payer, payee, amount_dec=Decimal("150.00"))
    assert risk_payee["is_blocked"] is True
    assert "per-payee" in risk_payee["block_reason"]

    # 3. Exceeds daily limit ($500.00) with prior payments
    now = datetime.datetime.now(datetime.timezone.utc)
    db.payment_intents.insert_one({
        "payer_id": payer["_id"],
        "amount": "450.00",
        "created_at": now,
        "status": "COMPLETED"
    })
    # Another $80 payment would bring daily total to $530 > $500
    risk_day = evaluate_risk(db, payer, payee, amount_dec=Decimal("80.00"))
    assert risk_day["is_blocked"] is True
    assert "daily" in risk_day["block_reason"]

def test_deterministic_scoring_rules(db, monkeypatch):
    """
    Acceptance criteria (Section 11):
    - First payment to payee: +25
    - Urgency keyword: +15
    - Scrubbed memo: +10
    """
    # Isolate deterministic rule evaluation from non-deterministic external LLM score elevation
    monkeypatch.setattr(
        "app.risk.llm.generate_risk_explanation",
        lambda *args, **kwargs: ("Standard deterministic risk assessment.", 0, None)
    )

    payer = create_mock_user(db, "veil-payer2")
    payee = create_mock_user(db, "veil-payee2")

    # 1. Clean first payment of $20.00 -> First payment (+25) -> Score 25 -> LOW
    r1 = evaluate_risk(db, payer, payee, amount_dec=Decimal("20.00"))
    assert r1["is_blocked"] is False
    assert r1["rule_score"] == 25
    assert r1["tier"] == "LOW"
    assert any("First payment" in r for r in r1["reasons"])

    # 2. First payment (+25) + urgency keyword 'urgent' (+15) + scrubbed note (+10)
    # Total = 50 -> MEDIUM tier
    r2 = evaluate_risk(
        db,
        payer,
        payee,
        amount_dec=Decimal("30.00"),
        raw_memo="urgent payment please",
        memo_flags=["phone_detected"]
    )
    assert r2["rule_score"] == 50
    assert r2["tier"] == "MEDIUM"
    assert any("urgency" in r.lower() for r in r2["reasons"])
    assert any("scrubbed" in r.lower() for r in r2["reasons"])

def test_llm_risk_explanation_and_elevation_invariant():
    """
    Acceptance criteria (Section 1, Rule 3 & Section 11):
    - The LLM can ONLY write a plain-language explanation (max 25 words).
    - The LLM may only raise the score, never lower it.
    - Fallback explanation is used if LLM call fails.
    """
    reasons = ["First payment to this payee (+25)", "Amount > 3x median (+20)"]
    explanation, extra_risk, pattern = generate_risk_explanation(
        rule_score=45,
        tier="MEDIUM",
        reasons=reasons,
        masked_memo="Standard transfer",
        amount_str="75.00",
        payer_alias="veil-payer",
        payee_alias="veil-payee"
    )

    # Explanation must be at most 25 words
    assert len(explanation.split()) <= 25
    assert isinstance(extra_risk, int)
    assert 0 <= extra_risk <= 20

