import json
import datetime
import pytest
from app import create_app
from app.db import get_db
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def register_user(client, email):
    resp = client.post('/auth/register/begin', json={"email": email})
    options = resp.get_json()
    challenge = base64url_to_bytes(options["challenge"])

    passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    cred = passkey.create_registration_credential(challenge)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    finish_resp = client.post('/auth/register/finish', json={
        "credential": cred
    }, headers={"X-CSRF-Token": csrf_token})
    return finish_resp.get_json()["alias"], passkey

def test_signature_replay_rejection(client, db):
    """
    Acceptance criteria:
    - Replaying a signed assertion for a second time MUST be rejected.
    """
    # 1. Register Payer and Payee
    client_bob = client.application.test_client()
    bob_alias, _ = register_user(client_bob, "bob_replay@test.local")
    alice_alias, alice_passkey = register_user(client, "alice_replay@test.local")

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # 2. Create Intent
    create_resp = client.post('/payments/intent', json={
        "payee_alias": bob_alias,
        "amount": "15.00",
        "memo": "Replay test"
    }, headers={"X-CSRF-Token": csrf_token})
    intent_id = create_resp.get_json()["intent"]["id"]

    # 3. Begin signing & sign legitimately
    sign_begin = client.post(f'/payments/{intent_id}/sign/begin')
    sign_options = sign_begin.get_json()
    challenge_bytes = base64url_to_bytes(sign_options["challenge"])
    assertion = alice_passkey.create_authentication_credential(challenge_bytes)

    # First sign attempt -> SUCCESS (200)
    sign_1 = client.post(f'/payments/{intent_id}/sign', json={
        "credential": assertion
    }, headers={"X-CSRF-Token": csrf_token})
    assert sign_1.status_code == 200

    # 4. Replay attempt: Attacker sends the exact same assertion payload again
    sign_replay = client.post(f'/payments/{intent_id}/sign', json={
        "credential": assertion
    }, headers={"X-CSRF-Token": csrf_token})
    
    # MUST BE REJECTED (400 Bad Request)
    assert sign_replay.status_code == 400
    assert "Cannot sign" in sign_replay.get_json()["error"] or "expired" in sign_replay.get_json()["error"] or "consumed" in sign_replay.get_json()["error"]

def test_intent_expiry_rejection(client, db):
    """
    Acceptance criteria:
    - Intents past the 5-minute TTL cannot be signed.
    """
    client_bob = client.application.test_client()
    bob_alias, _ = register_user(client_bob, "bob_expiry@test.local")
    alice_alias, alice_passkey = register_user(client, "alice_expiry@test.local")

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # Create Intent
    create_resp = client.post('/payments/intent', json={
        "payee_alias": bob_alias,
        "amount": "25.00"
    }, headers={"X-CSRF-Token": csrf_token})
    intent_id = create_resp.get_json()["intent"]["id"]

    # Artificially expire the intent in the database (set expires_at in the past)
    past_time = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(minutes=10)
    db.payment_intents.update_one(
        {"_id": __import__('bson').ObjectId(intent_id)},
        {"$set": {"expires_at": past_time}}
    )

    # Attempt to begin signing -> Rejected
    sign_begin = client.post(f'/payments/{intent_id}/sign/begin')
    assert sign_begin.status_code == 400
    assert "expired" in sign_begin.get_json()["error"].lower()

