import json
import pytest
from app import create_app
from app.db import get_db
from app.payments.intent import (
    build_canonical_intent,
    canonical_intent_bytes,
    compute_intent_hash
)
from app.ledger.ledger import verify_ledger_chain
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def register_user(client, email):
    resp = client.post('/auth/register/begin', json={"email": email})
    assert resp.status_code == 200
    options = resp.get_json()
    challenge = base64url_to_bytes(options["challenge"])

    passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    cred = passkey.create_registration_credential(challenge)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    finish_resp = client.post('/auth/register/finish', json={
        "credential": cred
    }, headers={"X-CSRF-Token": csrf_token})
    assert finish_resp.status_code == 201
    return finish_resp.get_json()["alias"], passkey

def test_intent_creation_canonical_hashing_and_signing(client, db):
    """
    Milestone M3 Test:
    - Create payment intent
    - Verify canonical intent format & SHA256 intent_hash
    - Begin signing & verify challenge equals intent_hash
    - Cryptographically sign with passkey
    - Verify state transition to AWAITING_PAYPAL_APPROVAL
    - Verify ledger append-only chain
    """
    # 1. Register Payer (Alice) and Payee (Bob)
    client_bob = client.application.test_client()
    bob_alias, _ = register_user(client_bob, "bob@test.local")
    alice_alias, alice_passkey = register_user(client, "alice@test.local")

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # 2. Alice creates intent to Bob for $12.50
    intent_resp = client.post('/payments/intent', json={
        "payee_alias": bob_alias,
        "amount": "12.50",
        "memo": "Dinner last night"
    }, headers={"X-CSRF-Token": csrf_token})

    assert intent_resp.status_code == 201
    intent_data = intent_resp.get_json()["intent"]
    intent_id = intent_data["id"]
    assert intent_data["amount"] == "12.50"
    assert intent_data["status"] == "AWAITING_SIGNATURE"
    assert intent_data["payer_alias"] == alice_alias
    assert intent_data["payee_alias"] == bob_alias

    # Verify intent stored in database
    intent_doc = db.payment_intents.find_one({"_id": __import__('bson').ObjectId(intent_id)})
    assert intent_doc is not None
    assert intent_doc["amount"] == "12.50"
    
    # Verify canonical hash integrity
    canon_bytes = canonical_intent_bytes(intent_doc["canonical_intent"])
    _, expected_hash_hex = compute_intent_hash(canon_bytes)
    assert intent_doc["intent_hash"] == expected_hash_hex

    # 3. Alice begins signing
    sign_begin_resp = client.post(f'/payments/{intent_id}/sign/begin')
    assert sign_begin_resp.status_code == 200
    sign_options = sign_begin_resp.get_json()
    challenge_bytes = base64url_to_bytes(sign_options["challenge"])

    # Invariant: challenge is EXACTLY the SHA256 intent_hash
    assert challenge_bytes == bytes.fromhex(intent_doc["intent_hash"])

    # 4. Alice signs with passkey
    assertion = alice_passkey.create_authentication_credential(challenge_bytes)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    sign_finish_resp = client.post(f'/payments/{intent_id}/sign', json={
        "credential": assertion
    }, headers={"X-CSRF-Token": csrf_token})

    assert sign_finish_resp.status_code == 200
    finish_data = sign_finish_resp.get_json()
    assert finish_data["payment_status"] == "AWAITING_PAYPAL_APPROVAL"

    # Verify database status updated
    updated_doc = db.payment_intents.find_one({"_id": intent_doc["_id"]})
    assert updated_doc["status"] == "AWAITING_PAYPAL_APPROVAL"
    assert updated_doc["signed_at"] is not None

    # Verify ledger integrity
    is_valid, count, msg = verify_ledger_chain(db)
    assert is_valid is True
    assert count >= 2  # Created + Signed

def test_signature_tamper_binding_amount_and_payee(client, db):
    """
    Acceptance criteria:
    - Signature binding: altering amount or payee invalidates the signature.
    """
    client_bob = client.application.test_client()
    bob_alias, _ = register_user(client_bob, "bob2@test.local")
    client_eve = client.application.test_client()
    eve_alias, _ = register_user(client_eve, "eve@test.local")
    alice_alias, alice_passkey = register_user(client, "alice2@test.local")

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # Alice creates intent to Bob for $20.00
    create_resp = client.post('/payments/intent', json={
        "payee_alias": bob_alias,
        "amount": "20.00",
        "memo": "Legitimate payment"
    }, headers={"X-CSRF-Token": csrf_token})
    intent_id = create_resp.get_json()["intent"]["id"]

    # Begin signing
    sign_begin = client.post(f'/payments/{intent_id}/sign/begin')
    assert sign_begin.status_code == 200

    # Tamper Scenario 1: Attacker attempts to forge a signature over a different amount ($200.00)
    fake_intent = build_canonical_intent(
        payer_alias=alice_alias,
        payee_alias=bob_alias,
        amount_str="200.00",  # Tampered amount
        currency="USD",
        memo_masked="Legitimate payment",
        nonce="fake_nonce",
        expires_at_iso="2026-11-08T12:00:00Z"
    )
    tampered_bytes = canonical_intent_bytes(fake_intent)
    tampered_hash_bytes, _ = compute_intent_hash(tampered_bytes)

    tampered_assertion = alice_passkey.create_authentication_credential(tampered_hash_bytes)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # Submitting tampered signature MUST FAIL
    tamper_resp = client.post(f'/payments/{intent_id}/sign', json={
        "credential": tampered_assertion
    }, headers={"X-CSRF-Token": csrf_token})
    assert tamper_resp.status_code == 400

    # Tamper Scenario 2: Attacker Eve attempts to sign Alice's payment with Eve's passkey
    eve_passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    # Begin signing again (since previous challenge was consumed on attempt)
    client.post(f'/payments/{intent_id}/sign/begin')
    intent_doc = db.payment_intents.find_one({"_id": __import__('bson').ObjectId(intent_id)})
    real_hash_bytes = bytes.fromhex(intent_doc["intent_hash"])
    eve_assertion = eve_passkey.create_authentication_credential(real_hash_bytes)

    eve_sign_resp = client.post(f'/payments/{intent_id}/sign', json={
        "credential": eve_assertion
    }, headers={"X-CSRF-Token": csrf_token})
    assert eve_sign_resp.status_code in (400, 401)

