import json
import pytest
from app import create_app
from app.db import get_db
from app.users.alias import generate_alias_string, is_valid_alias, create_unique_alias
from app.users.serializers import public_user, private_user, contact_shape
from app.security import encrypt_field
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def register_test_user(client, email="user@veilpay.test", payout_email=None):
    """Helper to register a user and return alias and user document."""
    resp = client.post('/auth/register/begin', json={
        "email": email,
        "payout_email": payout_email or email
    })
    assert resp.status_code == 200
    options = resp.get_json()
    challenge = base64url_to_bytes(options["challenge"])

    passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    cred = passkey.create_registration_credential(challenge)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    finish_resp = client.post('/auth/register/finish', json={
        "credential": cred
    }, headers={"X-CSRF-Token": csrf_token})

    assert finish_resp.status_code == 201
    return finish_resp.get_json()["alias"], passkey

def test_alias_format_and_uniqueness(db):
    """
    Acceptance criteria:
    - Server-side alias format: 'veil-' + 6 base32 characters.
    - User cannot forge arbitrary aliases.
    """
    alias = create_unique_alias(db)
    assert is_valid_alias(alias)
    assert alias.startswith("veil-")
    assert len(alias) == 11

    # Invalid aliases
    assert not is_valid_alias("veil-bank")      # not 6 chars
    assert not is_valid_alias("veil-123456")    # contains 1 (not in base32 alphabet)
    assert not is_valid_alias("admin")
    assert not is_valid_alias("veil-7X3K9M")    # uppercase must be rejected or normalized

def test_serializers_privacy_invariants():
    """
    Acceptance criteria:
    - public_user(u) returns ONLY {alias, display_name}.
    - Zero emails, raw IDs, limits, or hashes leak.
    """
    mock_user = {
        "_id": "672e1234567890abcdef1234",
        "alias": "veil-7x3k9m",
        "display_name": "MysteriousPayer",
        "contact_email_enc": "gAAAAABn...",
        "payout_email_enc": "gAAAAABm...",
        "limits": {"per_payment": "200.00", "per_day": "500.00"},
        "status": "active"
    }

    pub = public_user(mock_user)
    assert set(pub.keys()) == {"alias", "display_name"}
    assert pub["alias"] == "veil-7x3k9m"
    assert pub["display_name"] == "MysteriousPayer"

    # Invariant: Forbidden fields must not exist
    for forbidden in ("_id", "contact_email_enc", "payout_email_enc", "limits", "status"):
        assert forbidden not in pub

def test_public_user_endpoint_privacy(client, db):
    """
    Acceptance criteria:
    - GET /u/<alias> returns ONLY public user shape.
    - No email or internal details leak in the HTTP response.
    """
    secret_email = "alice.classified@corporate.gov"
    secret_payout = "alice.paypal.private@bank.com"
    alias_a, _ = register_test_user(client, email=secret_email, payout_email=secret_payout)

    resp = client.get(f'/u/{alias_a}')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "ok"
    assert data["user"]["alias"] == alias_a

    response_text = resp.get_data(as_text=True)
    assert secret_email not in response_text
    assert secret_payout not in response_text
    assert "_id" not in response_text
    assert "limits" not in response_text

def test_address_book_and_privacy(client, db):
    """
    Acceptance criteria:
    - Address book CRUD: list, add, delete.
    - Privacy invariant: payer only sees counterparty alias and assigned nickname.
    - Self-adding rejected. Non-existent alias rejected.
    """
    # Register User A (Alice)
    alias_a, _ = register_test_user(client, email="alice@test.com")
    
    # Register User B (Bob) using a clean client session
    app = client.application
    client_b = app.test_client()
    alias_b, _ = register_test_user(client_b, email="bob.private@domain.org", payout_email="bob.paypal@domain.org")

    # Alice logs into her session
    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # 1. Alice cannot add herself
    self_add = client.post('/contacts', json={"alias": alias_a}, headers={"X-CSRF-Token": csrf_token})
    assert self_add.status_code == 400
    assert "yourself" in self_add.get_json()["error"]

    # 2. Alice cannot add a non-existent alias
    fake_add = client.post('/contacts', json={"alias": "veil-234567"}, headers={"X-CSRF-Token": csrf_token})
    assert fake_add.status_code == 404

    # 3. Alice adds Bob to contacts with nickname and custom limit
    add_resp = client.post('/contacts', json={
        "alias": alias_b,
        "nickname": "Bob Freelancer",
        "per_payee_limit": "75.00"
    }, headers={"X-CSRF-Token": csrf_token})
    assert add_resp.status_code == 201
    contact = add_resp.get_json()["contact"]
    assert contact["alias"] == alias_b
    assert contact["nickname"] == "Bob Freelancer"
    assert contact["per_payee_limit"] == "75.00"

    # Verify no private emails leak in response
    add_text = add_resp.get_data(as_text=True)
    assert "bob.private@domain.org" not in add_text
    assert "bob.paypal@domain.org" not in add_text

    # 4. List contacts
    list_resp = client.get('/contacts')
    assert list_resp.status_code == 200
    contacts = list_resp.get_json()["contacts"]
    assert len(contacts) == 1
    assert contacts[0]["alias"] == alias_b
    assert contacts[0]["nickname"] == "Bob Freelancer"

    # 5. Delete contact
    del_resp = client.delete(f'/contacts/{alias_b}', headers={"X-CSRF-Token": csrf_token})
    assert del_resp.status_code == 200

    # Verify empty
    assert len(client.get('/contacts').get_json()["contacts"]) == 0

def test_display_name_pii_scrubbing(client, db):
    """
    Acceptance criteria:
    - Display name update runs through PII scrubber (Section 8).
    - Prevents users putting phone numbers or emails in display names.
    """
    alias, _ = register_test_user(client, email="carol@test.com")

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # Attempt to set display name containing a phone number
    patch_resp = client.patch('/me/settings', json={
        "display_name": "Carol +91 9876543210"
    }, headers={"X-CSRF-Token": csrf_token})

    assert patch_resp.status_code == 200
    updated_user = patch_resp.get_json()["user"]
    assert "9876543210" not in updated_user["display_name"]
    assert "[hidden]" in updated_user["display_name"]

    # Verify public profile shows scrubbed name
    pub_resp = client.get(f'/u/{alias}')
    pub_user = pub_resp.get_json()["user"]
    assert "9876543210" not in pub_user["display_name"]
    assert "[hidden]" in pub_user["display_name"]

