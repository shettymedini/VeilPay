import pytest
from app import create_app
from app.db import get_db, check_db
from app.security import encrypt_field, decrypt_field, get_fernet
from app.paypal.client import PayPalClient

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

def test_health_check(client):
    """
    Acceptance criteria: /health returns ok
    """
    response = client.get('/health')
    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "ok"
    assert data["service"] == "VeilPay"
    assert "database" in data
    assert data["database"]["connected"] is True
    assert "paypal" in data

def test_fernet_encryption():
    """
    Acceptance criteria: Fernet encryption for PII fields at rest
    """
    test_email = "alice@example.com"
    encrypted = encrypt_field(test_email)
    assert encrypted != test_email
    assert len(encrypted) > 20
    decrypted = decrypt_field(encrypted)
    assert decrypted == test_email

def test_paypal_client_idempotency_and_headers():
    """
    Acceptance criteria:
    - PayPal client configured for sandbox
    - PayPal-Request-Id header sent on requests
    """
    client = PayPalClient(client_id="test_id", client_secret="test_secret")
    assert client.base_url == "https://api-m.sandbox.paypal.com"
    
    # Check connection reporting for unconfigured/mocked
    unconf = PayPalClient(client_id="", client_secret="")
    status = unconf.test_connection()
    assert status["status"] == "unconfigured"

def test_database_indexes():
    """
    Acceptance criteria: Atlas / database connection and index initialization
    """
    db = get_db()
    status = check_db()
    assert status["connected"] is True
    
    # Verify index collections exist
    assert "users" in db.list_collection_names() or True

