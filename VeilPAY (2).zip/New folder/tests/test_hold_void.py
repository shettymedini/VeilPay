import json
import datetime
from decimal import Decimal
import pytest
from app import create_app
from app.db import get_db
from app.ledger.ledger import verify_ledger_chain
from app.payments.service import (
    initiate_paypal_order,
    authorize_paypal_return,
    void_authorized_payment,
    capture_and_payout,
    process_expired_holds
)
from app.paypal.client import PayPalClient
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def setup_signed_payment(client, amount="30.00", memo="Hold void test"):
    """Registers Alice and Bob, creates intent, and signs it."""
    # Bob (Payee)
    client_bob = client.application.test_client()
    bob_resp = client_bob.post('/auth/register/begin', json={"email": "bob_payee@test.local"})
    bob_opts = bob_resp.get_json()
    bob_pass = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    with client_bob.session_transaction() as sess:
        csrf_b = sess.get('_csrf_token')
    bob_reg = client_bob.post('/auth/register/finish', json={
        "credential": bob_pass.create_registration_credential(base64url_to_bytes(bob_opts["challenge"]))
    }, headers={"X-CSRF-Token": csrf_b})
    bob_alias = bob_reg.get_json()["alias"]

    # Alice (Payer)
    alice_resp = client.post('/auth/register/begin', json={"email": "alice_payer@test.local"})
    alice_opts = alice_resp.get_json()
    alice_pass = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    with client.session_transaction() as sess:
        csrf_a = sess.get('_csrf_token')
    alice_reg = client.post('/auth/register/finish', json={
        "credential": alice_pass.create_registration_credential(base64url_to_bytes(alice_opts["challenge"]))
    }, headers={"X-CSRF-Token": csrf_a})
    alice_alias = alice_reg.get_json()["alias"]

    with client.session_transaction() as sess:
        csrf_a = sess.get('_csrf_token')

    # Create intent
    create_res = client.post('/payments/intent', json={
        "payee_alias": bob_alias,
        "amount": amount,
        "memo": memo
    }, headers={"X-CSRF-Token": csrf_a})
    intent_id = create_res.get_json()["intent"]["id"]

    # Sign intent
    sign_beg = client.post(f'/payments/{intent_id}/sign/begin')
    ch_bytes = base64url_to_bytes(sign_beg.get_json()["challenge"])
    assertion = alice_pass.create_authentication_credential(ch_bytes)

    sign_res = client.post(f'/payments/{intent_id}/sign', json={
        "credential": assertion
    }, headers={"X-CSRF-Token": csrf_a})
    assert sign_res.status_code == 200

    return intent_id, alice_alias, bob_alias, csrf_a

def test_hold_and_void_flow(client, db):
    """
    Milestone M4 Test:
    - Authorize PayPal order and enter AUTHORIZED_HOLD
    - Verify hold countdown window exists
    - Payer presses 'This was not me' -> voids authorization
    - Status changes to CANCELLED_BY_PAYER
    - Verify ledger records void event
    """
    intent_id, alice_alias, bob_alias, csrf_token = setup_signed_payment(client, amount="25.00")

    # 1. Start PayPal checkout
    start_resp = client.get(f'/payments/{intent_id}/paypal/start?format=json')
    assert start_resp.status_code == 200
    start_data = start_resp.get_json()
    assert "approval_url" in start_data
    assert "order_id" in start_data

    # 2. Return from PayPal approval -> AUTHORIZED_HOLD
    return_resp = client.get(f'/payments/{intent_id}/paypal/return?format=json')
    assert return_resp.status_code == 200
    return_data = return_resp.get_json()
    assert return_data["payment_status"] == "AUTHORIZED_HOLD"
    assert return_data["hold_until"] is not None

    intent_doc = db.payment_intents.find_one({"_id": __import__('bson').ObjectId(intent_id)})
    assert intent_doc["status"] == "AUTHORIZED_HOLD"
    assert intent_doc["paypal"]["authorization_id"] is not None

    # 3. Payer triggers 'This was not me' -> Void
    void_resp = client.post(f'/payments/{intent_id}/void', json={
        "reason": "This was not me"
    }, headers={"X-CSRF-Token": csrf_token})

    assert void_resp.status_code == 200
    void_data = void_resp.get_json()
    assert void_data["payment_status"] == "CANCELLED_BY_PAYER"

    # Verify in DB
    updated = db.payment_intents.find_one({"_id": intent_doc["_id"]})
    assert updated["status"] == "CANCELLED_BY_PAYER"
    assert updated["hold_until"] is None

    # Verify ledger integrity
    is_valid, count, msg = verify_ledger_chain(db)
    assert is_valid is True

def test_hold_expiration_capture_and_payout_flow(client, db):
    """
    Milestone M4 Test:
    - Authorize PayPal order into AUTHORIZED_HOLD
    - Hold window expires (simulated past hold_until)
    - Background scheduler / process_expired_holds captures payment and executes payout
    - Status reaches COMPLETED
    - Ledger records CAPTURED, PAYOUT_SENT, and PAYMENT_COMPLETED
    """
    intent_id, alice_alias, bob_alias, csrf_token = setup_signed_payment(client, amount="40.00")

    # Authorize order
    client.get(f'/payments/{intent_id}/paypal/start?format=json')
    ret = client.get(f'/payments/{intent_id}/paypal/return?format=json')
    assert ret.status_code == 200

    # Simulate hold expiration by setting hold_until 1 minute in the past
    past_time = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(minutes=1)
    db.payment_intents.update_one(
        {"_id": __import__('bson').ObjectId(intent_id)},
        {"$set": {"hold_until": past_time}}
    )

    # Run hold expiration processor (APScheduler task)
    processed = process_expired_holds(db)
    assert intent_id in processed

    # Verify state machine reached COMPLETED
    completed_doc = db.payment_intents.find_one({"_id": __import__('bson').ObjectId(intent_id)})
    assert completed_doc["status"] == "COMPLETED"
    assert completed_doc["paypal"]["capture_id"] is not None
    assert completed_doc["paypal"]["payout_batch_id"] is not None

    # Verify tamper-evident ledger integrity
    is_valid, count, msg = verify_ledger_chain(db)
    assert is_valid is True

