import json
import pytest
from app import create_app
from app.db import get_db
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def test_passkey_registration_login_and_session(client, db):
    """
    Milestone M1 Acceptance Test:
    - Register with a passkey on localhost
    - Verify session is established and /me works
    - Log out and verify session expired
    - Log in with the passkey
    - Verify session works again
    - Verify challenge single-use / replay rejection
    """
    # 1. Begin registration
    email = "alice@example.com"
    resp = client.post('/auth/register/begin', json={"email": email})
    assert resp.status_code == 200
    reg_options = resp.get_json()
    assert "challenge" in reg_options
    assert reg_options["rp"]["id"] == "localhost"
    assert reg_options["authenticatorSelection"]["userVerification"] == "required"

    challenge_bytes = base64url_to_bytes(reg_options["challenge"])

    # 2. Virtual Passkey creates credentials
    passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    reg_credential = passkey.create_registration_credential(challenge_bytes)

    # Fetch CSRF token from session
    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    # 3. Finish registration
    headers = {"X-CSRF-Token": csrf_token} if csrf_token else {}
    finish_resp = client.post('/auth/register/finish', json={
        "credential": reg_credential,
        "label": "Alice's Laptop"
    }, headers=headers)

    assert finish_resp.status_code == 201
    reg_data = finish_resp.get_json()
    assert reg_data["status"] == "ok"
    alias = reg_data["alias"]
    assert alias.startswith("veil-")
    assert len(alias) == 11  # "veil-" + 6 chars = 11 chars

    # Verify user in database
    user = db.users.find_one({"alias": alias})
    assert user is not None
    # Verify contact email is encrypted at rest (not plaintext)
    assert user["contact_email_enc"] != email
    assert "alice@example.com" not in str(user)

    # 4. Verify session works with GET /me
    me_resp = client.get('/me')
    assert me_resp.status_code == 200
    me_data = me_resp.get_json()
    assert me_data["status"] == "ok"
    assert me_data["user"]["alias"] == alias
    assert me_data["user"]["limits"]["per_payment"] == "200.00"

    # Replay test: Attempting to finish registration again with same challenge must fail
    replay_resp = client.post('/auth/register/finish', json={
        "credential": reg_credential
    }, headers=headers)
    assert replay_resp.status_code in (400, 403)

    # 5. Log out
    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    logout_resp = client.post('/auth/logout', headers={"X-CSRF-Token": csrf_token})
    assert logout_resp.status_code == 200

    # Verify /me is now unauthorized (401)
    unauth_resp = client.get('/me')
    assert unauth_resp.status_code == 401

    # 6. Begin login
    login_begin_resp = client.post('/auth/login/begin', json={"alias": alias})
    assert login_begin_resp.status_code == 200
    login_options = login_begin_resp.get_json()
    assert "challenge" in login_options
    login_challenge_bytes = base64url_to_bytes(login_options["challenge"])

    # 7. Authenticate with virtual passkey
    auth_credential = passkey.create_authentication_credential(login_challenge_bytes)

    with client.session_transaction() as sess:
        csrf_token = sess.get('_csrf_token')

    login_finish_resp = client.post('/auth/login/finish', json={
        "credential": auth_credential
    }, headers={"X-CSRF-Token": csrf_token})

    assert login_finish_resp.status_code == 200
    login_data = login_finish_resp.get_json()
    assert login_data["status"] == "ok"
    assert login_data["alias"] == alias

    # 8. Verify session works after login
    me_after_login = client.get('/me')
    assert me_after_login.status_code == 200
    assert me_after_login.get_json()["user"]["alias"] == alias

