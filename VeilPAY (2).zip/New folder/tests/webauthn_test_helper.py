import os
import hashlib
import struct
import json
import cbor2
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes

class VirtualPasskey:
    """
    Simulates a WebAuthn passkey authenticator (W3C WebAuthn level 2/3)
    using SECP256R1 (ES256) for end-to-end testing without a physical device.
    """

    def __init__(self, rp_id="localhost", origin="http://localhost:5000", cred_id=None):
        self.rp_id = rp_id
        self.origin = origin
        self.private_key = ec.generate_private_key(ec.SECP256R1())
        self.cred_id = cred_id or (b"cred_" + os.urandom(12))
        self.sign_count = 0

    def get_cose_public_key(self) -> bytes:
        pub_numbers = self.private_key.public_key().public_numbers()
        x_bytes = pub_numbers.x.to_bytes(32, 'big')
        y_bytes = pub_numbers.y.to_bytes(32, 'big')
        return cbor2.dumps({1: 2, 3: -7, -1: 1, -2: x_bytes, -3: y_bytes})

    def create_registration_credential(self, challenge_bytes: bytes) -> dict:
        """
        Creates a valid RegistrationCredential for navigator.credentials.create() response.
        """
        challenge_b64 = bytes_to_base64url(challenge_bytes)
        rp_id_hash = hashlib.sha256(self.rp_id.encode('utf-8')).digest()
        flags = bytes([0x45])  # User Present (UP=1), User Verified (UV=1), Attested Credential (AT=1)
        sign_count_bytes = struct.pack('>I', self.sign_count)
        aaguid = b'\x00' * 16
        cred_id_len = struct.pack('>H', len(self.cred_id))
        cose_key = self.get_cose_public_key()

        auth_data = rp_id_hash + flags + sign_count_bytes + aaguid + cred_id_len + self.cred_id + cose_key
        attestation_obj = cbor2.dumps({'fmt': 'none', 'attStmt': {}, 'authData': auth_data})

        client_data = json.dumps({
            'type': 'webauthn.create',
            'challenge': challenge_b64,
            'origin': self.origin,
            'crossOrigin': False
        }).encode('utf-8')

        return {
            'id': bytes_to_base64url(self.cred_id),
            'rawId': bytes_to_base64url(self.cred_id),
            'response': {
                'clientDataJSON': bytes_to_base64url(client_data),
                'attestationObject': bytes_to_base64url(attestation_obj)
            },
            'type': 'public-key'
        }

    def create_authentication_credential(self, challenge_bytes: bytes) -> dict:
        """
        Creates a valid AuthenticationCredential for navigator.credentials.get() response.
        """
        self.sign_count += 1
        challenge_b64 = bytes_to_base64url(challenge_bytes)
        rp_id_hash = hashlib.sha256(self.rp_id.encode('utf-8')).digest()
        flags = bytes([0x05])  # User Present (UP=1), User Verified (UV=1)
        sign_count_bytes = struct.pack('>I', self.sign_count)
        auth_data = rp_id_hash + flags + sign_count_bytes

        client_data = json.dumps({
            'type': 'webauthn.get',
            'challenge': challenge_b64,
            'origin': self.origin,
            'crossOrigin': False
        }).encode('utf-8')
        client_data_hash = hashlib.sha256(client_data).digest()

        signature = self.private_key.sign(auth_data + client_data_hash, ec.ECDSA(hashes.SHA256()))

        return {
            'id': bytes_to_base64url(self.cred_id),
            'rawId': bytes_to_base64url(self.cred_id),
            'response': {
                'clientDataJSON': bytes_to_base64url(client_data),
                'authenticatorData': bytes_to_base64url(auth_data),
                'signature': bytes_to_base64url(signature)
            },
            'type': 'public-key'
        }

