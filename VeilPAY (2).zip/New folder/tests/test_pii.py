import pytest
from app.risk.pii import scrub_pii_regex, scrub_pii

def test_regex_scrubber_emails_and_urls():
    """
    Acceptance criteria (Section 12):
    - Replaces emails and URLs with [hidden].
    """
    raw = "Send receipt to alice.private@example.com or visit https://myportal.com/login"
    masked, found, flags = scrub_pii_regex(raw)

    assert found is True
    assert "alice.private@example.com" not in masked
    assert "https://myportal.com/login" not in masked
    assert "[hidden]" in masked
    assert "email_detected" in flags
    assert "url_detected" in flags

def test_regex_scrubber_phone_numbers_and_upi():
    """
    Acceptance criteria (Section 12):
    - Indian and international phones (+91, spaces, dashes)
    - UPI IDs (name@bank)
    """
    # Indian phone format with +91
    raw_in = "Call me on +91 98765 43210 for delivery confirmation"
    masked_in, found_in, flags_in = scrub_pii_regex(raw_in)
    assert found_in is True
    assert "98765" not in masked_in
    assert "[hidden]" in masked_in

    # Standard 10-digit number
    raw_std = "WhatsApp me on 9876543210"
    masked_std, found_std, _ = scrub_pii_regex(raw_std)
    assert found_std is True
    assert "9876543210" not in masked_std
    assert "[hidden]" in masked_std

    # UPI ID
    raw_upi = "Paying for services on merchant@okhdfcbank directly"
    masked_upi, found_upi, flags_upi = scrub_pii_regex(raw_upi)
    assert found_upi is True
    assert "merchant@okhdfcbank" not in masked_upi
    assert "[hidden]" in masked_upi
    assert "upi_detected" in flags_upi

def test_regex_scrubber_long_digit_runs():
    """
    Acceptance criteria (Section 12):
    - Long digit runs of 8 or more replaced with [hidden].
    """
    raw = "Account number 123456789012 for the transaction"
    masked, found, flags = scrub_pii_regex(raw)
    assert found is True
    assert "123456789012" not in masked
    assert "[hidden]" in masked
    assert "digit_run_detected" in flags

def test_clean_text_untouched():
    """Clean notes without PII must remain unchanged."""
    raw = "Thanks for dinner! Great time catching up."
    masked, found, flags = scrub_pii(raw)
    assert found is False
    assert flags == []
    assert masked == raw

def test_two_pass_obfuscated_scrubbing():
    """
    Acceptance criteria (Section 12):
    - Catches obfuscated text such as 'nine eight seven...' or 'name at gmail dot com'.
    """
    raw_spelled = "Contact me at alice at gmail dot com for details"
    masked, found, flags = scrub_pii(raw_spelled, enable_llm=True)
    assert found is True
    assert "alice at gmail dot com" not in masked
    assert "[hidden]" in masked

