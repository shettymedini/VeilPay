import pytest
from app import create_app
from app.db import get_db
from webauthn.helpers import base64url_to_bytes
from tests.webauthn_test_helper import VirtualPasskey

@pytest.fixture
def app():
    app = create_app({"TESTING": True, "DEMO_MODE": True})
    return app

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def db():
    return get_db(force_mock=True)

def login_test_user(client):
    resp = client.post('/auth/register/begin', json={"email": "tester_ui@veilpay.local"})
    opts = resp.get_json()
    passkey = VirtualPasskey(rp_id="localhost", origin="http://localhost:5000")
    with client.session_transaction() as sess:
        csrf_tok = sess.get('_csrf_token')
    reg = client.post('/auth/register/finish', json={
        "credential": passkey.create_registration_credential(base64url_to_bytes(opts["challenge"]))
    }, headers={"X-CSRF-Token": csrf_tok})
    return reg.get_json()["alias"]

def test_public_pages_render(client):
    """
    Acceptance criteria (Section 14):
    - Landing, register, login pages render cleanly.
    """
    # 1. Landing page
    landing_res = client.get('/')
    assert landing_res.status_code == 200
    assert "Pay anyone without exposing your phone" in landing_res.get_data(as_text=True)

    # 2. Register page
    reg_res = client.get('/register')
    assert reg_res.status_code == 200
    assert "Continue with fingerprint or face" in reg_res.get_data(as_text=True)
    assert "No passwords. No OTP" in reg_res.get_data(as_text=True)

    # 3. Login page
    login_res = client.get('/login')
    assert login_res.status_code == 200
    assert "Welcome Back to VeilPay" in login_res.get_data(as_text=True)

def test_authenticated_pages_render(client, db):
    """
    Acceptance criteria (Section 14):
    - Dashboard, pay, receive, activity, and security screens render for logged-in user.
    """
    alias = login_test_user(client)

    # 1. Dashboard
    dash_res = client.get('/dashboard')
    assert dash_res.status_code == 200
    dash_text = dash_res.get_data(as_text=True)
    assert alias in dash_text
    assert "Send Payment" in dash_text

    # 2. Pay screen
    pay_res = client.get('/pay')
    assert pay_res.status_code == 200
    assert "pay-memo" in pay_res.get_data(as_text=True)

    # 3. Receive screen
    rec_res = client.get('/receive')
    assert rec_res.status_code == 200
    assert alias in rec_res.get_data(as_text=True)

    # 4. Activity screen
    act_res = client.get('/activity')
    assert act_res.status_code == 200
    assert "Cryptographic Hash Chain Verified" in act_res.get_data(as_text=True)

    # 5. Security screen
    sec_res = client.get('/security')
    assert sec_res.status_code == 200
    assert "Spending Limits" in sec_res.get_data(as_text=True)

def test_demo_attack_simulations(client):
    """
    Acceptance criteria (Section 14):
    - Demo attack simulation panel:
      - Attacker tries to pay without signature -> blocked
      - Attacker replays a signed payment -> blocked
      - Attacker edits the amount -> blocked
    """
    # 1. Demo panel page
    demo_page = client.get('/demo')
    assert demo_page.status_code == 200
    assert "Attack Simulation Panel" in demo_page.get_data(as_text=True)

    # 2. Attack: No signature
    no_sig = client.post('/demo/attack', json={"type": "no_signature"})
    assert no_sig.status_code == 200
    d1 = no_sig.get_json()
    assert d1["blocked"] is True
    assert "AWAITING_SIGNATURE" in d1["reason"]

    # 3. Attack: Replay
    replay = client.post('/demo/attack', json={"type": "replay"})
    assert replay.status_code == 200
    d2 = replay.get_json()
    assert d2["blocked"] is True
    assert "already consumed" in d2["reason"]

    # 4. Attack: Tamper amount
    tamper = client.post('/demo/attack', json={"type": "tamper_amount"})
    assert tamper.status_code == 200
    d3 = tamper.get_json()
    assert d3["blocked"] is True
    assert d3["original_hash"] != d3["tampered_hash"]
    assert "binds the exact SHA-256" in d3["reason"]

