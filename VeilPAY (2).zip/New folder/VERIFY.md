# VeilPay: Verification & Testing Evidence (Working Sandbox Prototype)

This document provides transparent, verifiable evidence for the VeilPay Hackathon prototype.

---

## 1. Prototype Status & Honest Labeling

- **Prototype Classification:** **Working Sandbox Prototype** for the PayPal AI Hackathon 2026.
- **Not Real-Money Production:** This build runs on **PayPal Sandbox** (`https://api-m.sandbox.paypal.com`) with test buyer/seller accounts. Real-world financial deployment would require regulatory licensing, full KYC verification, anti-money laundering (AML) controls, and hardware security modules (HSMs).
- **Dual PayPal Authorization Paths:**
  - **Path 1 (Full External Portal):** Redirects to `https://www.sandbox.paypal.com/checkoutnow` where the buyer logs in using a PayPal Sandbox test buyer account.
  - **Path 2 (1-Click Fast-Track Demo Approval):** For quick demonstration and evaluation, simulates buyer consent on the pre-created order and transitions directly into the `AUTHORIZED_HOLD` state so evaluators can inspect the safety hold countdown, the "This was not me" void action, and the ledger chain without having to manually fill out external sandbox forms.

---

## 2. Automated Test Suite (27 / 27 Passed)

Executed with `pytest -v`:
```
platform win32 -- Python 3.12.10, pytest-9.2.0
collected 27 items

tests/test_hold_void.py::test_hold_and_void_flow PASSED                  [  3%]
tests/test_hold_void.py::test_hold_expiration_capture_and_payout_flow PASSED [  7%]
tests/test_m0_setup.py::test_health_check PASSED                         [ 11%]
tests/test_m0_setup.py::test_fernet_encryption PASSED                    [ 14%]
tests/test_m0_setup.py::test_paypal_client_idempotency_and_headers PASSED [ 18%]
tests/test_m0_setup.py::test_database_indexes PASSED                     [ 22%]
tests/test_passkeys.py::test_passkey_registration_login_and_session PASSED [ 25%]
tests/test_pii.py::test_regex_scrubber_emails_and_urls PASSED            [ 29%]
tests/test_pii.py::test_regex_scrubber_phone_numbers_and_upi PASSED      [ 33%]
tests/test_pii.py::test_regex_scrubber_long_digit_runs PASSED            [ 37%]
tests/test_pii.py::test_clean_text_untouched PASSED                      [ 40%]
tests/test_pii.py::test_two_pass_obfuscated_scrubbing PASSED             [ 44%]
tests/test_privacy.py::test_alias_format_and_uniqueness PASSED           [ 48%]
tests/test_privacy.py::test_serializers_privacy_invariants PASSED        [ 51%]
tests/test_privacy.py::test_public_user_endpoint_privacy PASSED          [ 55%]
tests/test_privacy.py::test_address_book_and_privacy PASSED              [ 59%]
tests/test_privacy.py::test_display_name_pii_scrubbing PASSED            [ 62%]
tests/test_replay.py::test_signature_replay_rejection PASSED             [ 66%]
tests/test_replay.py::test_intent_expiry_rejection PASSED                [ 70%]
tests/test_risk.py::test_hard_limits_block_payments PASSED               [ 74%]
tests/test_risk.py::test_deterministic_scoring_rules PASSED              [ 77%]
tests/test_risk.py::test_llm_risk_explanation_and_elevation_invariant PASSED [ 81%]
tests/test_signing.py::test_intent_creation_canonical_hashing_and_signing PASSED [ 85%]
tests/test_signing.py::test_signature_tamper_binding_amount_and_payee PASSED [ 88%]
tests/test_ui_and_demo.py::test_public_pages_render PASSED               [ 92%]
tests/test_ui_and_demo.py::test_authenticated_pages_render PASSED        [ 96%]
tests/test_ui_and_demo.py::test_demo_attack_simulations PASSED           [100%]

====================== 27 passed, 130 warnings in 13.39s ======================
```

---

## 3. Live System Health Check Verification

Calling `GET http://localhost:5000/health`:
```json
{
  "database": {
    "connected": true,
    "mode": "MongoDB Atlas",
    "status": "ok"
  },
  "demo_mode": true,
  "paypal": {
    "expires_in_sec": 32279,
    "status": "connected",
    "token_cached": true
  },
  "service": "VeilPay",
  "status": "ok",
  "version": "1.0.0"
}
```

---

## 4. End-to-End Walkthrough Script Verification

Executed live via `.\.venv\Scripts\python.exe dummy_test.py`:
- Registered Payee (Bob) with virtual passkey $\rightarrow$ Assigned alias `veil-fg4rwl`.
- Registered Payer (Tina) with virtual passkey $\rightarrow$ Assigned alias `veil-fvx4cd`.
- Payer created payment with note containing phone number: `"Call my cell 415-555-2671"`.
- PII Scrubber automatically detected digit run and sanitized note to: `"Call my cell [hidden] if any questions."`
- Payer's passkey cryptographically signed `SHA-256(canonical_intent)`.
- PayPal order authorized into `AUTHORIZED_HOLD` state.
- Bob's `/receive` view inspected: confirmed Bob only sees `veil-fvx4cd` and masked note; zero PII leaked.
- "This was not me" triggered: PayPal authorization successfully voided, status `CANCELLED_BY_PAYER`.
- Tamper-evident ledger audited: all 6 blocks verified intact.

---

## 5. Security & Privacy Invariants

1. **Allowlist Serializers:** All endpoints returning user data use `public_user()` or `private_user()`. Mongo user documents are never returned raw.
2. **Deterministic Risk Invariant:** The AI layer can only raise risk scores by up to +20 points and provide natural language explanations; it cannot lower scores or approve payments.
3. **Replay Invariant:** Single-use challenges are immediately deleted from `webauthn_challenges` upon first verification attempt.
4. **Origin Binding:** WebAuthn assertions verify the relying party ID (`localhost` or production domain) to prevent phishing.
5. **Secret Protection:** `.env` is listed in `.gitignore`. No tokens, secrets, or decrypted emails are logged.

