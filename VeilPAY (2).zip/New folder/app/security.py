import time
import os
import secrets
from functools import wraps
from flask import request, session, jsonify, g
from cryptography.fernet import Fernet
import logging

logger = logging.getLogger(__name__)

_fernet_instance = None

def get_fernet():
    """
    Returns singleton Fernet cipher instance.
    If FERNET_KEY is not set or invalid, generates a deterministic or ephemeral key.
    """
    global _fernet_instance
    if _fernet_instance is not None:
        return _fernet_instance

    from app.config import Config
    key = Config.FERNET_KEY
    if not key:
        # Fallback for development/testing: generate a new Fernet key if missing
        key = Fernet.generate_key().decode('utf-8')
        logger.warning("FERNET_KEY was not set in environment. Generated ephemeral key for session.")
    
    if isinstance(key, str):
        key = key.encode('utf-8')

    try:
        _fernet_instance = Fernet(key)
    except Exception as e:
        logger.error("Invalid FERNET_KEY format: %s. Generating fallback key.", e)
        fallback = Fernet.generate_key()
        _fernet_instance = Fernet(fallback)
        
    return _fernet_instance

def encrypt_field(plaintext: str) -> str:
    """
    Encrypts a string field using Fernet.
    Returns URL-safe base64 string.
    """
    if not plaintext:
        return ""
    f = get_fernet()
    return f.encrypt(plaintext.encode('utf-8')).decode('utf-8')

def decrypt_field(ciphertext: str) -> str:
    """
    Decrypts a Fernet ciphertext.
    Returns plaintext string.
    """
    if not ciphertext:
        return ""
    f = get_fernet()
    try:
        return f.decrypt(ciphertext.encode('utf-8')).decode('utf-8')
    except Exception as e:
        logger.error("Failed to decrypt ciphertext: %s", e)
        return ""

def generate_csrf_token():
    """Generates or retrieves CSRF token stored in user session."""
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']

def verify_csrf(req=None):
    """
    Validates CSRF token from header (X-CSRF-Token) or JSON body.
    """
    req = req or request
    if req.method in ('GET', 'HEAD', 'OPTIONS'):
        return True
    
    expected = session.get('_csrf_token')
    if not expected:
        return False
        
    provided = req.headers.get('X-CSRF-Token')
    if not provided and req.is_json and req.json:
        provided = req.json.get('csrf_token')
        
    if not provided or not secrets.compare_digest(str(provided), str(expected)):
        return False
    return True

def require_csrf(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not verify_csrf():
            return jsonify({"error": "Invalid or missing CSRF token"}), 403
        return f(*args, **kwargs)
    return decorated_function

def require_login(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get('user_id')
        last_active = session.get('last_active')
        now = time.time()
        
        # 30-minute idle session timeout
        if not user_id or not last_active or (now - last_active > 1800):
            session.clear()
            return jsonify({"error": "Session expired or unauthorized. Please authenticate with your passkey."}), 401
            
        session['last_active'] = now
        return f(*args, **kwargs)
    return decorated_function

# Basic in-memory rate limiter for auth and payment endpoints
_rate_limits = {}

def rate_limit(limit_count=20, window_seconds=60):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            ip = request.remote_addr or '127.0.0.1'
            key = f"{ip}:{request.endpoint}"
            now = time.time()
            
            history = _rate_limits.get(key, [])
            # Purge entries older than window
            history = [t for t in history if now - t < window_seconds]
            
            if len(history) >= limit_count:
                return jsonify({
                    "error": "Rate limit exceeded. Please wait a moment.",
                    "retry_after": int(window_seconds - (now - history[0]))
                }), 429
                
            history.append(now)
            _rate_limits[key] = history
            return f(*args, **kwargs)
        return wrapped
    return decorator

