import hashlib
import json
import datetime
from bson import ObjectId

def canonical_event_data(event: str, data: dict, ts_iso: str) -> str:
    """
    Serializes event, data, and timestamp deterministically with sorted keys and no whitespace.
    """
    payload = {
        "event": event,
        "data": data,
        "ts": ts_iso
    }
    return json.dumps(payload, sort_keys=True, separators=(',', ':'))

def append_ledger_entry(db, intent_id, event: str, data: dict) -> dict:
    """
    Appends a new event to the tamper-evident ledger (Section 7 & 10).
    hash = SHA256(prev_hash + canonical(event, data, ts))
    """
    # Find last entry to get sequence and prev_hash
    last_entry = db.ledger.find_one(sort=[("seq", -1)])
    if last_entry:
        seq = last_entry["seq"] + 1
        prev_hash = last_entry["hash"]
    else:
        seq = 1
        prev_hash = "0" * 64  # Genesis prev_hash

    now_dt = datetime.datetime.now(datetime.timezone.utc)
    ts_iso = now_dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    canonical_repr = canonical_event_data(event, data, ts_iso)
    
    entry_hash = hashlib.sha256((prev_hash + canonical_repr).encode('utf-8')).hexdigest()

    entry = {
        "seq": seq,
        "intent_id": str(intent_id) if intent_id else None,
        "event": event,
        "data": data,
        "prev_hash": prev_hash,
        "hash": entry_hash,
        "ts": ts_iso
    }
    db.ledger.insert_one(entry)
    return entry

def verify_ledger_chain(db) -> tuple[bool, int, str]:
    """
    Walks and verifies cryptographic integrity of the entire ledger hash chain.
    Returns (is_valid, count_verified, message).
    """
    entries = list(db.ledger.find().sort("seq", 1))
    if not entries:
        return True, 0, "Ledger is empty"

    expected_prev = "0" * 64
    for i, entry in enumerate(entries):
        if entry["seq"] != i + 1:
            return False, i, f"Sequence mismatch at seq {entry['seq']}"
        if entry["prev_hash"] != expected_prev:
            return False, i, f"Broken prev_hash chain at seq {entry['seq']}"

        ts_str = str(entry["ts"])
        canonical_repr = canonical_event_data(entry["event"], entry["data"], ts_str)
        computed_hash = hashlib.sha256((entry["prev_hash"] + canonical_repr).encode('utf-8')).hexdigest()

        if computed_hash != entry["hash"]:
            return False, i, f"Hash tamper detected at seq {entry['seq']}"

        expected_prev = entry["hash"]

    return True, len(entries), "Ledger verified intact"

