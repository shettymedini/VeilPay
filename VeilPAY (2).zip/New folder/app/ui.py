import datetime
from flask import Blueprint, render_template, redirect, url_for, session, request
from bson import ObjectId
from app.db import get_db
from app.config import Config
from app.security import require_login
from app.users.serializers import public_user, private_user, contact_shape
from app.ledger.ledger import verify_ledger_chain

ui_bp = Blueprint('ui', __name__)

@ui_bp.route('/')
def landing():
    if session.get('user_id'):
        return redirect(url_for('ui.dashboard'))
    return render_template('landing.html', rp_id=Config.RP_ID)

@ui_bp.route('/register')
def register():
    if session.get('user_id'):
        return redirect(url_for('ui.dashboard'))
    return render_template('register.html', rp_id=Config.RP_ID)

@ui_bp.route('/login')
def login():
    if session.get('user_id'):
        return redirect(url_for('ui.dashboard'))
    return render_template('login.html', rp_id=Config.RP_ID)

@ui_bp.route('/dashboard')
@require_login
def dashboard():
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        session.clear()
        return redirect(url_for('ui.login'))

    # Fetch recent payments for dashboard
    recent_intents = list(db.payment_intents.find({
        "$or": [{"payer_id": user["_id"]}, {"payee_id": user["_id"]}]
    }).sort("created_at", -1).limit(5))

    # Fetch contacts for quick payments
    raw_contacts = list(db.contacts.find({"owner_id": ObjectId(user_id)}).sort("created_at", -1))
    contacts = []
    for c in raw_contacts:
        shape = contact_shape(c)
        u = db.users.find_one({"alias": c["alias"]})
        shape["display_name"] = c.get("nickname") or (u.get("display_name") if u else None) or c["alias"]
        contacts.append(shape)

    return render_template(
        'dashboard.html',
        user=private_user(user),
        recent_intents=recent_intents,
        contacts=contacts,
        demo_mode=Config.DEMO_MODE,
        origin=Config.ORIGIN
    )

@ui_bp.route('/pay')
@ui_bp.route('/pay/<alias>')
@require_login
def pay(alias=None):
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})
    contacts = list(db.contacts.find({"owner_id": ObjectId(user_id)}).sort("created_at", -1))
    target_alias = alias or request.args.get('alias') or request.args.get('to', '')

    enriched_contacts = []
    for c in contacts:
        shape = contact_shape(c)
        u = db.users.find_one({"alias": c["alias"]})
        shape["display_name"] = c.get("nickname") or (u.get("display_name") if u else None) or c["alias"]
        cnt = db.payment_intents.count_documents({
            "payer_id": ObjectId(user_id),
            "payee_alias": c["alias"],
            "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
        })
        shape["prior_payments_count"] = cnt
        enriched_contacts.append(shape)

    return render_template(
        'pay.html',
        user=private_user(user),
        contacts=enriched_contacts,
        target_alias=target_alias
    )

@ui_bp.route('/review/<intent_id>')
@require_login
def review(intent_id):
    db = get_db()
    user_id = session.get('user_id')
    try:
        intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    except Exception:
        return redirect(url_for('ui.dashboard'))

    if not intent or str(intent["payer_id"]) != str(user_id):
        return redirect(url_for('ui.dashboard'))

    # Calculate exact remaining signature window on server
    remaining_seconds = 0
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    exp = intent.get("expires_at")
    if exp:
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=datetime.timezone.utc)
        if exp <= now_utc:
            if intent.get("status") == "AWAITING_SIGNATURE":
                db.payment_intents.update_one(
                    {"_id": intent["_id"]},
                    {"$set": {"status": "EXPIRED", "updated_at": now_utc}}
                )
                intent["status"] = "EXPIRED"
            remaining_seconds = 0
        else:
            remaining_seconds = max(0, int((exp - now_utc).total_seconds()))

    payee_alias = intent.get("payee_alias")
    payee_user = db.users.find_one({"alias": payee_alias})
    contact = db.contacts.find_one({"owner_id": ObjectId(user_id), "alias": payee_alias})
    payee_display_name = (contact.get("nickname") if contact else None) or (payee_user.get("display_name") if payee_user else None) or payee_alias
    prior_payments_count = db.payment_intents.count_documents({
        "payer_id": ObjectId(user_id),
        "payee_alias": payee_alias,
        "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    })
    should_suggest_contact = (contact is None and prior_payments_count >= 1)

    return render_template(
        'review.html',
        intent=intent,
        payee_display_name=payee_display_name,
        remaining_seconds=remaining_seconds,
        total_ttl_seconds=Config.INTENT_TTL_SECONDS,
        prior_payments_count=prior_payments_count,
        should_suggest_contact=should_suggest_contact,
        is_in_contacts=contact is not None
    )

@ui_bp.route('/status')
@ui_bp.route('/status/<intent_id>')
@require_login
def status_page(intent_id=None):
    db = get_db()
    user_id = session.get('user_id')
    iid = intent_id or request.args.get('intent_id')
    intent = None
    if iid:
        try:
            intent = db.payment_intents.find_one({"_id": ObjectId(iid)})
        except Exception:
            pass

    if not intent:
        # Fallback to user's most recent payment intent
        intent = db.payment_intents.find_one(
            {"$or": [{"payer_id": ObjectId(user_id)}, {"payee_id": ObjectId(user_id)}]},
            sort=[("created_at", -1)]
        )

    if not intent:
        return redirect(url_for('ui.pay'))

    is_payer = str(intent["payer_id"]) == str(user_id)
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    remaining_seconds = 0
    total_timer_seconds = 60

    # 1. Active Safety Hold Timer
    if intent.get("status") == "AUTHORIZED_HOLD" and intent.get("hold_until"):
        hold_dt = intent["hold_until"]
        if hold_dt.tzinfo is None:
            hold_dt = hold_dt.replace(tzinfo=datetime.timezone.utc)
        tier = intent.get("risk", {}).get("tier", "LOW")
        total_timer_seconds = Config.LOW_HOLD_SECONDS if tier == "LOW" else Config.MEDIUM_HOLD_SECONDS
        
        diff = (hold_dt - now_utc).total_seconds()
        # If hold has elapsed (0 or negative), capture it
        if diff <= 0:
            try:
                from app.payments.service import capture_and_payout
                intent = capture_and_payout(db, intent["_id"])
                remaining_seconds = 0
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning("Could not auto-capture expired hold on status load: %s", e)
                remaining_seconds = 0
        else:
            remaining_seconds = max(0, int(diff))

    # 2. Awaiting Signature Window Timer
    elif intent.get("status") == "AWAITING_SIGNATURE" and intent.get("expires_at"):
        exp = intent["expires_at"]
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=datetime.timezone.utc)
        total_timer_seconds = Config.INTENT_TTL_SECONDS
        if exp <= now_utc:
            db.payment_intents.update_one(
                {"_id": intent["_id"]},
                {"$set": {"status": "EXPIRED", "updated_at": now_utc}}
            )
            intent["status"] = "EXPIRED"
            remaining_seconds = 0
        else:
            remaining_seconds = max(0, int((exp - now_utc).total_seconds()))

    # Check contact recommendation
    payee_alias = intent.get("payee_alias")
    payee_user = db.users.find_one({"alias": payee_alias})
    contact = db.contacts.find_one({"owner_id": ObjectId(user_id), "alias": payee_alias})
    payee_display_name = (contact.get("nickname") if contact else None) or (payee_user.get("display_name") if payee_user else None) or payee_alias
    prior_payments_count = db.payment_intents.count_documents({
        "payer_id": ObjectId(user_id),
        "payee_alias": payee_alias,
        "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    })
    should_suggest_contact = (is_payer and contact is None and prior_payments_count >= 1)

    return render_template(
        'status.html',
        intent=intent,
        payee_display_name=payee_display_name,
        is_payer=is_payer,
        remaining_seconds=remaining_seconds,
        total_hold_seconds=total_timer_seconds,
        total_timer_seconds=total_timer_seconds,
        prior_payments_count=prior_payments_count,
        should_suggest_contact=should_suggest_contact,
        is_in_contacts=contact is not None
    )

@ui_bp.route('/receive')
@require_login
def receive():
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})

    received_intents = list(db.payment_intents.find({
        "payee_id": user["_id"],
        "status": {"$in": ["PAYOUT_SENT", "COMPLETED", "AUTHORIZED_HOLD", "CAPTURED"]}
    }).sort("created_at", -1))

    return render_template(
        'receive.html',
        user=private_user(user),
        received_intents=received_intents,
        origin=Config.ORIGIN
    )

@ui_bp.route('/activity')
@require_login
def activity():
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})

    # Ledger audit
    is_valid, count, msg = verify_ledger_chain(db)
    
    # User's ledger events
    user_alias = user["alias"]
    all_events = list(db.ledger.find().sort("seq", -1).limit(50))
    user_events = [
        e for e in all_events
        if e.get("data", {}).get("payer_alias") == user_alias
        or e.get("data", {}).get("payee_alias") == user_alias
        or e.get("data", {}).get("signer_alias") == user_alias
        or e.get("data", {}).get("voided_by") == user_alias
    ]

    return render_template(
        'activity.html',
        events=user_events,
        chain_verified=is_valid,
        verified_count=count
    )

@ui_bp.route('/security')
@require_login
def security():
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})
    credentials = list(db.credentials.find({"user_id": user["_id"]}).sort("created_at", -1))

    return render_template(
        'security.html',
        user=private_user(user),
        credentials=credentials
    )

@ui_bp.route('/demo')
def demo():
    if not Config.DEMO_MODE:
        return redirect(url_for('ui.landing'))
    return render_template('demo.html')

