/**
 * VeilPay WebAuthn (Passkey) Client Library
 * Handles W3C WebAuthn ceremony transformations between JSON and ArrayBuffers.
 */

function base64urlToBuffer(base64urlString) {
    const padding = '='.repeat((4 - (base64urlString.length % 4)) % 4);
    const base64 = (base64urlString + padding)
        .replace(/\-/g, '+')
        .replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray.buffer;
}

function bufferToBase64url(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    const base64 = window.btoa(binary);
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) return meta.content;
    const match = document.cookie.match(new RegExp('(^| )csrf_token=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : '';
}

async function registerPasskey(email, payoutEmail = '', label = 'Primary Device', displayName = '') {
    // 1. Begin registration
    const beginRes = await fetch('/auth/register/begin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
        },
        body: JSON.stringify({ email, payout_email: payoutEmail, display_name: displayName })
    });

    if (!beginRes.ok) {
        const err = await beginRes.json();
        throw new Error(err.error || 'Failed to begin passkey registration');
    }

    const options = await beginRes.json();

    // Transform options for navigator.credentials.create
    options.challenge = base64urlToBuffer(options.challenge);
    options.user.id = base64urlToBuffer(options.user.id);
    if (options.excludeCredentials) {
        for (let cred of options.excludeCredentials) {
            cred.id = base64urlToBuffer(cred.id);
        }
    }

    // 2. Invoke browser WebAuthn API (Face / Fingerprint / PIN prompt)
    const credential = await navigator.credentials.create({ publicKey: options });

    // 3. Serialize credential back to JSON
    const credPayload = {
        id: credential.id,
        rawId: bufferToBase64url(credential.rawId),
        response: {
            clientDataJSON: bufferToBase64url(credential.response.clientDataJSON),
            attestationObject: bufferToBase64url(credential.response.attestationObject)
        },
        type: credential.type
    };

    // 4. Finish registration
    const finishRes = await fetch('/auth/register/finish', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
        },
        body: JSON.stringify({ credential: credPayload, label, display_name: displayName })
    });

    const finishData = await finishRes.json();
    if (!finishRes.ok) {
        throw new Error(finishData.error || 'Failed to verify passkey');
    }

    return finishData;
}

async function loginPasskey(alias = '') {
    // 1. Begin login
    const beginRes = await fetch('/auth/login/begin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
        },
        body: JSON.stringify({ alias })
    });

    if (!beginRes.ok) {
        const err = await beginRes.json();
        throw new Error(err.error || 'Failed to begin login');
    }

    const options = await beginRes.json();

    // Transform options for navigator.credentials.get
    options.challenge = base64urlToBuffer(options.challenge);
    if (options.allowCredentials) {
        for (let cred of options.allowCredentials) {
            cred.id = base64urlToBuffer(cred.id);
        }
    }

    // 2. Prompt user verification
    const assertion = await navigator.credentials.get({ publicKey: options });

    // 3. Serialize assertion
    const assertionPayload = {
        id: assertion.id,
        rawId: bufferToBase64url(assertion.rawId),
        response: {
            clientDataJSON: bufferToBase64url(assertion.response.clientDataJSON),
            authenticatorData: bufferToBase64url(assertion.response.authenticatorData),
            signature: bufferToBase64url(assertion.response.signature),
            userHandle: assertion.response.userHandle ? bufferToBase64url(assertion.response.userHandle) : null
        },
        type: assertion.type
    };

    // 4. Finish login
    const finishRes = await fetch('/auth/login/finish', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
        },
        body: JSON.stringify({ credential: assertionPayload })
    });

    const finishData = await finishRes.json();
    if (!finishRes.ok) {
        throw new Error(finishData.error || 'Failed to verify passkey login');
    }

    return finishData;
}

