/**
 * VeilPay Frontend App Logic
 * - Live PII Note Detection
 * - Countdown Timers
 * - Clipboard Copying
 * - Attack Simulations
 */

// 1. Live Privacy Check on Note / Memo field
function initLiveNotePrivacyChecker(noteInputId, hintContainerId) {
    const input = document.getElementById(noteInputId);
    const hint = document.getElementById(hintContainerId);
    if (!input || !hint) return;

    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
    const phoneRegex = /(\+?\d{1,4}[-.\s]?)?(\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}/;
    const digitRunRegex = /\b\d{8,}\b/;
    const upiRegex = /@[a-zA-Z]{2,}/;

    input.addEventListener('input', () => {
        const val = input.value;
        const hasEmail = emailRegex.test(val);
        const hasPhone = phoneRegex.test(val) && (val.replace(/\D/g, '').length >= 7);
        const hasDigits = digitRunRegex.test(val);
        const hasUpi = upiRegex.test(val);

        if (hasEmail || hasPhone || hasDigits || hasUpi) {
            hint.innerHTML = `
                <div class="privacy-hint-alert">
                    <span>🛡️ Live Privacy Shield:</span>
                    <span>Contact details detected! We will automatically scrub this before sharing to preserve your privacy.</span>
                </div>
            `;
            hint.style.display = 'block';
        } else {
            hint.style.display = 'none';
        }
    });
}

// 2. Countdown Timer for Hold Window (Zero-lag, frame-0 instant render, smooth progress)
function initHoldCountdown(paramA, paramB, onExpire) {
    const display = document.getElementById('countdown-timer');
    const progressBar = document.getElementById('countdown-progress-bar');
    const statusText = document.getElementById('countdown-status-text');
    if (!display) return;

    let secondsLeft = 60;
    let totalSeconds = 60;
    let timer = null;
    let expiredHandled = false;

    // Check if called as (remainingSeconds, totalHoldSeconds, onExpire)
    if (typeof paramA === 'number' || (typeof paramA === 'string' && !paramA.includes('-'))) {
        secondsLeft = Math.max(0, parseInt(paramA, 10) || 0);
        totalSeconds = Math.max(1, parseInt(paramB, 10) || 60);
    } else if (typeof paramA === 'string' && paramA.includes('-')) {
        let isoStr = paramA;
        if (!isoStr.endsWith('Z') && !isoStr.includes('+')) {
            isoStr += 'Z';
        }
        const targetTime = new Date(isoStr).getTime();
        const now = new Date().getTime();
        secondsLeft = Math.max(0, Math.floor((targetTime - now) / 1000));
        totalSeconds = typeof paramB === 'number' ? paramB : 60;
        if (typeof paramB === 'function') onExpire = paramB;
    } else {
        secondsLeft = Math.max(0, parseInt(paramA, 10) || 60);
        totalSeconds = Math.max(1, parseInt(paramB, 10) || 60);
    }

    function render() {
        const minutes = Math.floor(secondsLeft / 60);
        const seconds = secondsLeft % 60;
        display.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        if (progressBar) {
            const pct = Math.min(100, Math.max(0, (secondsLeft / totalSeconds) * 100));
            progressBar.style.width = `${pct}%`;
        }

        if (secondsLeft <= 0) {
            if (timer) clearInterval(timer);
            if (expiredHandled) return;
            expiredHandled = true;

            display.innerText = "00:00";
            if (statusText) statusText.innerText = "Safety hold elapsed. Auto-capturing and transferring payout...";
            if (typeof onExpire === 'function') {
                onExpire();
            }
        }
    }

    // Immediate Frame 0 render
    render();

    // Only start interval if there is time remaining
    if (secondsLeft > 0) {
        timer = setInterval(() => {
            secondsLeft -= 1;
            render();
        }, 1000);
    }
}

// 3. Copy to Clipboard
function copyText(text, btnElement) {
    navigator.clipboard.writeText(text).then(() => {
        const originalText = btnElement.innerText;
        btnElement.innerText = "Copied!";
        setTimeout(() => {
            btnElement.innerText = originalText;
        }, 2000);
    });
}

// 4. Attack Simulator Runner (Demo Screen)
async function triggerAttackSimulation(attackType, resultContainerId) {
    const container = document.getElementById(resultContainerId);
    if (!container) return;

    container.innerHTML = `<div class="alert alert-warning">Simulating attack vector: ${attackType}...</div>`;

    try {
        const res = await fetch('/demo/attack', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': getCsrfToken()
            },
            body: JSON.stringify({ type: attackType })
        });

        const data = await res.json();
        if (data.blocked) {
            container.innerHTML = `
                <div class="alert alert-danger" style="margin-top: 14px;">
                    <h4 style="margin-bottom: 6px; color: #991B1B;">🛑 Attack Blocked: ${data.status}</h4>
                    <p style="color: #7F1D1D; margin-bottom: 8px;"><strong>Reason:</strong> ${data.reason}</p>
                    <pre style="background: #FFF; padding: 10px; border-radius: 6px; font-size: 0.85rem; border: 1px solid #FECACA; overflow-x: auto;">${JSON.stringify(data, null, 2)}</pre>
                </div>
            `;
        } else {
            container.innerHTML = `<div class="alert alert-warning">Response: ${JSON.stringify(data)}</div>`;
        }
    } catch (err) {
        container.innerHTML = `<div class="alert alert-danger">Simulation failed: ${err.message}</div>`;
    }
}

// 5. Awaiting Signature Review Timer (Zero-lag, frame-0 instant render)
function initReviewTimer(remainingSecs, totalSecs, onExpire) {
    const display = document.getElementById('review-timer');
    const progressBar = document.getElementById('review-progress-bar');
    const statusText = document.getElementById('review-status-text');
    const signBtn = document.getElementById('sign-btn');
    if (!display) return;

    let secondsLeft = Math.max(0, parseInt(remainingSecs, 10) || 0);
    const totalSeconds = Math.max(1, parseInt(totalSecs, 10) || 300);

    function render() {
        const minutes = Math.floor(secondsLeft / 60);
        const seconds = secondsLeft % 60;
        display.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

        if (progressBar) {
            const pct = Math.min(100, Math.max(0, (secondsLeft / totalSeconds) * 100));
            progressBar.style.width = `${pct}%`;
        }

        if (secondsLeft <= 0) {
            clearInterval(timer);
            display.innerText = "00:00";
            if (statusText) statusText.innerText = "⚠️ Signature window expired. Single-use hash invalidated.";
            if (signBtn) {
                signBtn.disabled = true;
                signBtn.style.opacity = '0.5';
                signBtn.innerHTML = "<span>⚠️ Intent Expired — Create New Payment</span>";
                signBtn.onclick = () => window.location.href = '/pay';
            }
            if (typeof onExpire === 'function') onExpire();
        }
    }

    render();
    const timer = setInterval(() => {
        secondsLeft -= 1;
        render();
    }, 1000);
}

// 6. Save Contact AJAX Helper
async function saveContactAjax(alias, nickname, btnEl, feedbackEl) {
    if (btnEl) {
        btnEl.disabled = true;
        btnEl.innerText = "Saving...";
    }

    try {
        const res = await fetch('/users/contacts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': getCsrfToken()
            },
            body: JSON.stringify({
                alias: alias,
                nickname: nickname || ""
            })
        });

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.error || "Failed to save contact.");
        }

        if (btnEl) {
            btnEl.innerText = "✓ Saved!";
            btnEl.classList.remove('btn-primary');
            btnEl.classList.add('btn-accent');
        }
        if (feedbackEl) {
            feedbackEl.innerText = `✓ Saved ${nickname || alias} to your contacts!`;
            feedbackEl.style.display = 'block';
            feedbackEl.style.color = '#34D399';
        }
    } catch (err) {
        if (btnEl) {
            btnEl.disabled = false;
            btnEl.innerText = "Save to Contacts";
        }
        if (feedbackEl) {
            feedbackEl.innerText = err.message;
            feedbackEl.style.display = 'block';
            feedbackEl.style.color = '#F87171';
        }
    }
}

// 7. Live Payee Insight Checker on Pay Screen
function initLivePayeeCheck(inputElId, hintContainerId) {
    const input = document.getElementById(inputElId);
    const container = document.getElementById(hintContainerId);
    if (!input || !container) return;

    let debounceTimer = null;

    input.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        const val = input.value.trim().toLowerCase();

        if (!val.startsWith('veil-') || val.length < 8) {
            container.style.display = 'none';
            container.innerHTML = '';
            return;
        }

        debounceTimer = setTimeout(async () => {
            try {
                const res = await fetch(`/users/contacts/payee_insight?alias=${encodeURIComponent(val)}`);
                if (!res.ok) return;
                const data = await res.json();

                if (data.exists && data.should_suggest) {
                    container.style.display = 'block';
                    container.innerHTML = `
                        <div style="background: rgba(37, 99, 235, 0.12); border: 1px solid rgba(59, 130, 246, 0.45); border-radius: 12px; padding: 12px 14px; margin-top: 10px;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <span style="font-size: 1.1rem;">💡</span>
                                <div style="font-size: 0.84rem; color: #93C5FD; font-weight: 600;">
                                    AI Insight: You've paid this person ${data.prior_payments_count} time${data.prior_payments_count > 1 ? 's' : ''}! Save to contacts for 1-click access?
                                </div>
                            </div>
                            <div style="display: flex; gap: 8px; margin-top: 8px;">
                                <input type="text" id="inline-nickname-${data.alias}" class="form-input" style="padding: 6px 12px; font-size: 0.85rem;" placeholder="Nickname (e.g. Freelancer Bob)">
                                <button type="button" class="btn btn-primary btn-sm" onclick="handleInlineContactSave('${data.alias}', this)">
                                    Save
                                </button>
                            </div>
                            <div id="inline-feedback-${data.alias}" style="font-size: 0.78rem; margin-top: 4px; display: none;"></div>
                        </div>
                    `;
                } else {
                    container.style.display = 'none';
                    container.innerHTML = '';
                }
            } catch (e) {
                // Ignore transient lookup errors
            }
        }, 300);
    });
}

function handleInlineContactSave(alias, btnEl) {
    const nickInput = document.getElementById(`inline-nickname-${alias}`);
    const feedbackEl = document.getElementById(`inline-feedback-${alias}`);
    const nick = nickInput ? nickInput.value.trim() : '';
    saveContactAjax(alias, nick, btnEl, feedbackEl);
}

