import logging
from flask import Flask, jsonify, session
from app.config import Config
from app.db import get_db, check_db
from app.paypal.client import PayPalClient
from app.security import generate_csrf_token
from app.auth.routes import auth_bp
from app.users.routes import users_bp
from app.payments.routes import payments_bp
from app.ui import ui_bp
from app.demo import demo_bp

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger(__name__)

def create_app(config_overrides=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    
    if config_overrides:
        app.config.update(config_overrides)
        
    # Initialize database
    get_db()
    
    @app.before_request
    def ensure_session_csrf():
        generate_csrf_token()

    # Context processor to inject CSRF token into templates
    @app.context_processor
    def inject_csrf_token():
        return dict(csrf_token=generate_csrf_token())
        
    @app.after_request
    def set_csrf_cookie(response):
        # Set CSRF cookie for client-side JS fetch requests
        if '_csrf_token' in session:
            response.set_cookie(
                'csrf_token',
                session['_csrf_token'],
                samesite='Lax',
                secure=app.config.get('SESSION_COOKIE_SECURE', False)
            )
        return response

    # PWA Endpoints for Android / Mobile
    @app.route('/manifest.json')
    def pwa_manifest():
        return app.send_static_file('manifest.json')

    @app.route('/sw.js')
    def pwa_service_worker():
        response = app.send_static_file('sw.js')
        response.headers['Content-Type'] = 'application/javascript'
        response.headers['Service-Worker-Allowed'] = '/'
        return response

    # M0 Health endpoint
    @app.route('/health', methods=['GET'])
    def health_check():
        db_status = check_db()
        paypal_client = PayPalClient()
        paypal_status = paypal_client.test_connection()
        
        status_ok = db_status.get('status') == 'ok'
        
        return jsonify({
            "status": "ok" if status_ok else "degraded",
            "service": "VeilPay",
            "version": "1.0.0",
            "database": db_status,
            "paypal": paypal_status,
            "demo_mode": app.config.get('DEMO_MODE', True)
        }), 200 if status_ok else 503

    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(payments_bp)
    app.register_blueprint(ui_bp)
    app.register_blueprint(demo_bp)

    # Start hold-expiry capture scheduler
    if not app.config.get('TESTING', False):
        try:
            from app.payments.scheduler import init_scheduler
            init_scheduler(app)
        except Exception as e:
            logger.warning("Scheduler startup notice: %s", e)

    logger.info("VeilPay Flask application successfully initialized.")
    return app

