import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
env_path = Path(__file__).resolve().parent.parent / '.env'
load_dotenv(dotenv_path=env_path)

class Config:
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY', 'veilpay-hackathon-default-secret-key-32b')
    MONGODB_URI = os.getenv('MONGODB_URI', '')
    
    # WebAuthn Relying Party configuration
    RP_ID = os.getenv('RP_ID', 'localhost')
    RP_NAME = os.getenv('RP_NAME', 'VeilPay')
    ORIGIN = os.getenv('ORIGIN', 'http://localhost:5000')
    
    # PayPal Sandbox Configuration
    PAYPAL_CLIENT_ID = os.getenv('PAYPAL_CLIENT_ID', '')
    PAYPAL_CLIENT_SECRET = os.getenv('PAYPAL_CLIENT_SECRET', '')
    PAYPAL_BASE_URL = os.getenv('PAYPAL_BASE_URL', 'https://api-m.sandbox.paypal.com')
    
    # Platform Encryption (Fernet) for PII fields at rest
    FERNET_KEY = os.getenv('FERNET_KEY', '')
    
    # AI Risk Engine (Groq, Gemini, Anthropic, OpenAI)
    GROQ_API_KEY = os.getenv('GROQ_API_KEY', '')
    LLM_API_KEY = os.getenv('GROQ_API_KEY', '') or os.getenv('LLM_API_KEY', '')
    LLM_MODEL = os.getenv('LLM_MODEL', 'openai/gpt-oss-120b' if (os.getenv('GROQ_API_KEY') or os.getenv('LLM_API_KEY', '').startswith('gsk_')) else 'gemini-1.5-flash')
    
    # Operation Mode & Hold Timers
    DEMO_MODE = os.getenv('DEMO_MODE', 'true').lower() in ('true', '1', 'yes')
    LOW_HOLD_SECONDS = int(os.getenv('LOW_HOLD_SECONDS', '60'))
    MEDIUM_HOLD_SECONDS = int(os.getenv('MEDIUM_HOLD_SECONDS', '60'))
    INTENT_TTL_SECONDS = int(os.getenv('INTENT_TTL_SECONDS', '300'))
    
    # Security Settings
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = os.getenv('ORIGIN', '').startswith('https://')
    PERMANENT_SESSION_LIFETIME = 1800  # 30-minute idle timeout

