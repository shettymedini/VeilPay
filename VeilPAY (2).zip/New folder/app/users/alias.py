import secrets
import string
import re

# Standard Base32 alphabet (lowercase)
BASE32_ALPHABET = "abcdefghijklmnopqrstuvwxyz234567"
ALIAS_REGEX = re.compile(r"^veil-[a-z2-7]{6}$")

def generate_alias_string() -> str:
    """Generates a random alias string matching 'veil-' followed by 6 base32 chars."""
    random_chars = ''.join(secrets.choice(BASE32_ALPHABET) for _ in range(6))
    return f"veil-{random_chars}"

def is_valid_alias(alias: str) -> bool:
    """Validates alias format."""
    if not alias or not isinstance(alias, str):
        return False
    return bool(ALIAS_REGEX.match(alias.strip().lower()))

def create_unique_alias(db, max_attempts=10) -> str:
    """
    Generates a unique alias, ensuring no duplicate exists in the users collection.
    """
    for _ in range(max_attempts):
        alias = generate_alias_string()
        if not db.users.find_one({"alias": alias}):
            return alias
    raise RuntimeError("Failed to generate a unique alias after multiple attempts.")

