def public_user(user_doc: dict) -> dict:
    """
    Public shape: ONLY alias and optional display_name.
    Privacy invariant: Never exposes emails, phones, IDs, or real names.
    """
    if not user_doc:
        return {}
    return {
        "alias": user_doc.get("alias", ""),
        "display_name": user_doc.get("display_name", "")
    }

def private_user(user_doc: dict) -> dict:
    """
    Private shape: Exposes own alias, display_name, limits, cooling hours, and status to the authenticated owner.
    Privacy invariant: Even the private shape never returns raw database IDs or unmasked secrets.
    """
    if not user_doc:
        return {}
    return {
        "alias": user_doc.get("alias", ""),
        "display_name": user_doc.get("display_name", ""),
        "limits": user_doc.get("limits", {
            "per_payment": "200.00",
            "per_day": "500.00",
            "per_payee_default": "100.00"
        }),
        "new_payee_cooling_hours": user_doc.get("new_payee_cooling_hours", 24),
        "status": user_doc.get("status", "active"),
        "created_at": user_doc.get("created_at").isoformat() if user_doc.get("created_at") else None
    }

def contact_shape(contact_doc: dict) -> dict:
    """
    Allowlist shape for contacts in the user's address book.
    Privacy invariant: Contains only alias and user-defined nickname/limits.
    """
    if not contact_doc:
        return {}
    return {
        "alias": contact_doc.get("alias", ""),
        "nickname": contact_doc.get("nickname", ""),
        "first_paid_at": contact_doc.get("first_paid_at").isoformat() if contact_doc.get("first_paid_at") else None,
        "per_payee_limit": contact_doc.get("per_payee_limit"),
        "created_at": contact_doc.get("created_at").isoformat() if contact_doc.get("created_at") else None
    }

