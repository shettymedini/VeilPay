import os
import re
import datetime
from decimal import Decimal, InvalidOperation
from flask import Blueprint, request, jsonify, session
from bson import ObjectId

from app.config import Config
from app.db import get_db
from app.security import require_login, require_csrf, rate_limit
from app.users.serializers import public_user, private_user, contact_shape
from app.users.alias import is_valid_alias
from app.risk.pii import scrub_pii_regex

users_bp = Blueprint('users', __name__)

@users_bp.route('/me', methods=['GET'])
@require_login
def get_me():
    """
    Returns authenticated user's private shape.
    """
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        return jsonify({"error": "User not found"}), 404
        
    return jsonify({
        "status": "ok",
        "user": private_user(user)
    }), 200

@users_bp.route('/me/settings', methods=['PATCH'])
@require_login
@require_csrf
def update_settings():
    """
    Updates the authenticated user's limits, cooling hours, and display name.
    Runs display_name through the PII scrubber (Section 8).
    """
    db = get_db()
    user_id = session.get('user_id')
    user = db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        return jsonify({"error": "User not found"}), 404

    data = request.get_json() or {}
    updates = {}

    # 1. Update display name with PII scrubbing
    if 'display_name' in data:
        raw_name = str(data['display_name']).strip()
        if raw_name:
            scrubbed_name, found, _ = scrub_pii_regex(raw_name)
            updates['display_name'] = scrubbed_name
        else:
            updates['display_name'] = ""

    # 2. Update cooling hours
    if 'new_payee_cooling_hours' in data:
        try:
            cooling_hours = int(data['new_payee_cooling_hours'])
            if cooling_hours < 0:
                return jsonify({"error": "Cooling hours must be a non-negative integer."}), 400
            updates['new_payee_cooling_hours'] = cooling_hours
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid cooling hours value."}), 400

    # 3. Update spending limits
    if 'limits' in data and isinstance(data['limits'], dict):
        current_limits = user.get('limits', {})
        new_limits = dict(current_limits)

        for key in ('per_payment', 'per_day', 'per_payee_default'):
            if key in data['limits']:
                try:
                    val = Decimal(str(data['limits'][key]))
                    if val <= 0:
                        return jsonify({"error": f"Limit for {key} must be greater than zero."}), 400
                    new_limits[key] = f"{val:.2f}"
                except (InvalidOperation, TypeError):
                    return jsonify({"error": f"Invalid decimal limit value for {key}."}), 400

        updates['limits'] = new_limits

    if updates:
        db.users.update_one({"_id": user["_id"]}, {"$set": updates})
        user = db.users.find_one({"_id": user["_id"]})

    return jsonify({
        "status": "ok",
        "message": "Settings updated successfully.",
        "user": private_user(user)
    }), 200

@users_bp.route('/contacts', methods=['GET'])
@users_bp.route('/users/contacts', methods=['GET'])
@require_login
def list_contacts():
    """
    Lists user's address book contacts (alias-only).
    """
    db = get_db()
    user_id = session.get('user_id')
    contacts = list(db.contacts.find({"owner_id": ObjectId(user_id)}).sort("created_at", -1))
    
    return jsonify({
        "status": "ok",
        "contacts": [contact_shape(c) for c in contacts]
    }), 200

@users_bp.route('/contacts/payee_insight', methods=['GET'])
@users_bp.route('/users/contacts/payee_insight', methods=['GET'])
@require_login
def payee_insight():
    """
    Returns contact status and prior payment count for a given payee alias.
    Enables AI to advise: 'You have paid this person X times! Save to contacts?'
    """
    db = get_db()
    user_id = session.get('user_id')
    alias = str(request.args.get('alias', '')).strip().lower()

    if not alias:
        return jsonify({"error": "Missing alias parameter"}), 400

    target_user = db.users.find_one({"alias": alias, "status": "active"})
    if not target_user:
        return jsonify({"exists": False, "is_contact": False, "prior_payments_count": 0}), 200

    contact = db.contacts.find_one({"owner_id": ObjectId(user_id), "alias": alias})
    prior_count = db.payment_intents.count_documents({
        "payer_id": ObjectId(user_id),
        "payee_alias": alias,
        "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    })

    return jsonify({
        "status": "ok",
        "exists": True,
        "alias": alias,
        "is_contact": contact is not None,
        "nickname": contact.get("nickname") if contact else None,
        "prior_payments_count": prior_count,
        "should_suggest": (contact is None and prior_count >= 1),
        "suggestion": f"You've paid this person {prior_count} time(s) before! Save them to your contacts for fast access?" if (contact is None and prior_count >= 1) else None
    }), 200

@users_bp.route('/profile/display_name', methods=['POST'])
@users_bp.route('/users/profile/display_name', methods=['POST'])
@require_login
@require_csrf
def set_display_name():
    """
    Sets the user's public display name (e.g. 'apple', 'green', 'Tina')
    which allows friends and contacts to address them without typing random aliases.
    """
    db = get_db()
    user_id = session.get('user_id')
    data = request.get_json() or {}
    name = str(data.get('display_name', '')).strip()
    if name:
        name, _, _ = scrub_pii_regex(name)
        name = name[:30]

    db.users.update_one({"_id": ObjectId(user_id)}, {"$set": {"display_name": name}})
    session['display_name'] = name
    return jsonify({
        "status": "ok",
        "display_name": name,
        "message": f"Public name set to '{name}'!" if name else "Public name cleared."
    }), 200

@users_bp.route('/resolve_payee', methods=['GET'])
@users_bp.route('/users/resolve_payee', methods=['GET'])
@require_login
def resolve_payee_api():
    """
    Live payee resolution: Given a nickname, public name (e.g. 'green'), or alias,
    returns the matched user and alias details.
    """
    db = get_db()
    user_id = session.get('user_id')
    raw_query = str(request.args.get('query', '')).strip()
    query = raw_query.lstrip('@')
    if not query:
        return jsonify({"found": False}), 200

    clean_query = query.lower()

    # 1. Search payer's contacts by nickname or alias
    contact = db.contacts.find_one({
        "owner_id": ObjectId(user_id),
        "$or": [
            {"nickname": {"$regex": f"^{re.escape(query)}$", "$options": "i"}},
            {"alias": clean_query}
        ]
    })
    if contact:
        target_u = db.users.find_one({"alias": contact["alias"], "status": "active"})
        if target_u:
            return jsonify({
                "found": True,
                "alias": target_u["alias"],
                "display_name": contact.get("nickname") or target_u.get("display_name") or target_u["alias"],
                "is_contact": True,
                "contact_nickname": contact.get("nickname")
            }), 200

    # 2. Search all users by display_name (public name)
    target_u = db.users.find_one({
        "display_name": {"$regex": f"^{re.escape(query)}$", "$options": "i"},
        "status": "active"
    })
    if target_u:
        return jsonify({
            "found": True,
            "alias": target_u["alias"],
            "display_name": target_u.get("display_name") or target_u["alias"],
            "is_contact": False
        }), 200

    # 3. Search all users by alias
    target_u = db.users.find_one({"alias": clean_query, "status": "active"})
    if target_u:
        return jsonify({
            "found": True,
            "alias": target_u["alias"],
            "display_name": target_u.get("display_name") or target_u["alias"],
            "is_contact": False
        }), 200

    return jsonify({"found": False, "query": raw_query}), 200

@users_bp.route('/contacts/seed_demo', methods=['POST'])
@users_bp.route('/users/contacts/seed_demo', methods=['POST'])
@require_login
@require_csrf
def seed_demo_contacts():
    """
    Seeds demo contacts (e.g. Alice, green, Bob) into the current user's address book.
    Ensures demo users exist in the database and links them directly.
    """
    db = get_db()
    user_id = session.get('user_id')
    current_alias = session.get('alias')

    demo_profiles = [
        {"alias": "veil-utgx42", "display_name": "apple", "nickname": "apple (Friend)"},
        {"alias": "veil-bi5s6j", "display_name": "green", "nickname": "green (Best Friend)"},
        {"alias": "veil-mh5al3", "display_name": "Bob", "nickname": "Bob (Freelancer)"}
    ]

    added_count = 0
    for p in demo_profiles:
        if p["alias"] == current_alias:
            continue
        # Ensure user exists in db
        existing_user = db.users.find_one({"alias": p["alias"]})
        if not existing_user:
            db.users.insert_one({
                "alias": p["alias"],
                "display_name": p["display_name"],
                "limits": {"per_payment": "200.00", "per_day": "500.00", "per_payee_default": "100.00"},
                "new_payee_cooling_hours": 24,
                "status": "active",
                "created_at": datetime.datetime.now(datetime.timezone.utc)
            })
        else:
            if not existing_user.get("display_name"):
                db.users.update_one({"_id": existing_user["_id"]}, {"$set": {"display_name": p["display_name"]}})

        # Add or update contact
        db.contacts.update_one(
            {"owner_id": ObjectId(user_id), "alias": p["alias"]},
            {
                "$set": {
                    "nickname": p["nickname"],
                    "updated_at": datetime.datetime.now(datetime.timezone.utc)
                },
                "$setOnInsert": {
                    "owner_id": ObjectId(user_id),
                    "alias": p["alias"],
                    "per_payee_limit": "100.00",
                    "created_at": datetime.datetime.now(datetime.timezone.utc)
                }
            },
            upsert=True
        )
        added_count += 1

    contacts = list(db.contacts.find({"owner_id": ObjectId(user_id)}).sort("created_at", -1))
    return jsonify({
        "status": "ok",
        "added": added_count,
        "contacts": [contact_shape(c) for c in contacts]
    }), 200

@users_bp.route('/contacts', methods=['POST'])
@users_bp.route('/users/contacts', methods=['POST'])
@require_login
@require_csrf
def add_contact():
    """
    Adds a contact to the payer's address book by alias or public name (e.g. 'green', 'apple').
    Resolves public name to user alias, creates demo user if in demo mode, and saves.
    """
    db = get_db()
    user_id = session.get('user_id')
    current_alias = session.get('alias')

    data = request.get_json() or {}
    raw_target = str(data.get('alias', '')).strip()
    target_clean = raw_target.lstrip('@')
    nickname = str(data.get('nickname', '')).strip()
    per_payee_limit = data.get('per_payee_limit')

    if not target_clean:
        return jsonify({"error": "Please provide an alias or public name (e.g. green)."}), 400

    target_alias = target_clean.lower()
    target_user = None

    # 1. Check if it's already an alias format
    if is_valid_alias(target_alias):
        target_user = db.users.find_one({"alias": target_alias, "status": "active"})
        if not target_user:
            return jsonify({"error": f"No active user found with alias '{raw_target}'."}), 404
    else:
        # 2. Check if it's a public display_name (e.g. 'green' or 'apple')
        target_user = db.users.find_one({
            "display_name": {"$regex": f"^{re.escape(target_clean)}$", "$options": "i"},
            "status": "active"
        })

        # 3. If still not found by name and in demo mode, auto-provision a demo friend with this name!
        if not target_user and (Config.DEMO_MODE or os.environ.get("FLASK_ENV") != "production"):
            from app.users.alias import create_unique_alias
            new_alias = create_unique_alias(db)
            target_user = {
                "alias": new_alias,
                "display_name": target_clean,
                "limits": {"per_payment": "200.00", "per_day": "500.00", "per_payee_default": "100.00"},
                "new_payee_cooling_hours": 24,
                "status": "active",
                "created_at": datetime.datetime.now(datetime.timezone.utc)
            }
            db.users.insert_one(target_user)

    if not target_user:
        return jsonify({"error": f"No active user found with name or alias '{raw_target}'."}), 404

    final_alias = target_user["alias"]

    if final_alias == current_alias:
        return jsonify({"error": "You cannot add yourself to your address book."}), 400

    # Default nickname to user's display name if not specified
    if not nickname:
        nickname = target_user.get("display_name", "") or final_alias

    # Format per_payee_limit if provided
    formatted_limit = None
    if per_payee_limit is not None:
        try:
            dec_limit = Decimal(str(per_payee_limit))
            if dec_limit <= 0:
                return jsonify({"error": "Per-payee limit must be greater than zero."}), 400
            formatted_limit = f"{dec_limit:.2f}"
        except (InvalidOperation, TypeError):
            return jsonify({"error": "Invalid per_payee_limit format."}), 400

    # Scrub nickname for PII
    if nickname:
        nickname, _, _ = scrub_pii_regex(nickname)

    owner_obj_id = ObjectId(user_id)
    existing = db.contacts.find_one({"owner_id": owner_obj_id, "alias": final_alias})
    if existing:
        # Update existing contact
        db.contacts.update_one(
            {"_id": existing["_id"]},
            {
                "$set": {
                    "nickname": nickname or existing.get("nickname", ""),
                    "per_payee_limit": formatted_limit or existing.get("per_payee_limit")
                }
            }
        )
        updated = db.contacts.find_one({"_id": existing["_id"]})
        return jsonify({
            "status": "ok",
            "message": f"Updated contact '{nickname}'!",
            "contact": contact_shape(updated)
        }), 200

    contact_doc = {
        "owner_id": owner_obj_id,
        "alias": final_alias,
        "nickname": nickname,
        "first_paid_at": None,
        "per_payee_limit": formatted_limit,
        "created_at": datetime.datetime.now(datetime.timezone.utc)
    }
    result = db.contacts.insert_one(contact_doc)
    contact_doc["_id"] = result.inserted_id

    return jsonify({
        "status": "ok",
        "message": f"Added '{nickname}' to your contacts!",
        "contact": contact_shape(contact_doc)
    }), 201

@users_bp.route('/contacts/<alias>', methods=['DELETE'])
@require_login
@require_csrf
def delete_contact(alias):
    """
    Deletes a contact from the address book.
    """
    db = get_db()
    user_id = session.get('user_id')
    clean_alias = alias.strip().lower()

    result = db.contacts.delete_one({"owner_id": ObjectId(user_id), "alias": clean_alias})
    if result.deleted_count == 0:
        return jsonify({"error": "Contact not found in your address book."}), 404

    return jsonify({
        "status": "ok",
        "message": f"Contact '{clean_alias}' removed successfully."
    }), 200

@users_bp.route('/u/<alias>', methods=['GET'])
def get_public_user(alias):
    """
    Public shape: alias and display name only (Section 8 & 13).
    Privacy Invariant: NEVER exposes email, phone, PayPal email, or database ID.
    """
    db = get_db()
    clean_alias = alias.strip().lower()

    user = db.users.find_one({"alias": clean_alias, "status": "active"})
    if not user:
        return jsonify({"error": "User not found"}), 404

    return jsonify({
        "status": "ok",
        "user": public_user(user)
    }), 200
