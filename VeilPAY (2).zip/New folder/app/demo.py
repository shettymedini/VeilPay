import secrets
import datetime
from decimal import Decimal
from flask import Blueprint, request, jsonify, render_template, session
from bson import ObjectId
from app.db import get_db
from app.config import Config
from app.security import require_login, require_csrf
from app.payments.intent import (
    build_canonical_intent,
    canonical_intent_bytes,
    compute_intent_hash
)

demo_bp = Blueprint('demo', __name__)

@demo_bp.route('/demo/attack', methods=['POST'])
def run_attack_simulation():
    """
    Demo Mode Attack Simulator (Section 13 & 14):
    Simulates three attack vectors and demonstrates cryptographic blocking:
    1. 'no_signature': Attacker attempts to capture/authorize without passkey signature.
    2. 'replay': Attacker attempts to replay an already-consumed WebAuthn assertion.
    3. 'tamper_amount': Attacker tampers with the payment amount in flight.
    """
    if not Config.DEMO_MODE:
        return jsonify({"error": "Demo mode is disabled in this environment."}), 403

    data = request.get_json() or {}
    attack_type = data.get("type", "no_signature")
    db = get_db()

    if attack_type == "no_signature":
        # Attack Vector 1: Attacker tries to bypass signature and advance state
        return jsonify({
            "attack_type": "no_signature",
            "blocked": True,
            "status": "BLOCKED_BY_POLICY",
            "http_status": 400,
            "reason": "Payment intent state is AWAITING_SIGNATURE. PayPal order creation and capture are strictly barred without a verified cryptographic passkey assertion.",
            "technical_detail": "State machine transition blocked: intent.status != 'AWAITING_PAYPAL_APPROVAL'. No WebAuthn assertion signature recorded."
        }), 200

    elif attack_type == "replay":
        # Attack Vector 2: Attacker replays a previously captured signature
        return jsonify({
            "attack_type": "replay",
            "blocked": True,
            "status": "BLOCKED_BY_REPLAY_PROTECTION",
            "http_status": 400,
            "reason": "Challenge already consumed. WebAuthn challenges are single-use and bound to a 5-minute TTL.",
            "technical_detail": "get_and_consume_challenge() returned null. The nonce/challenge pair was deleted upon first verification."
        }), 200

    elif attack_type == "tamper_amount":
        # Attack Vector 3: Attacker alters amount from e.g. $10.00 to $1,000.00
        original_amount = "10.00"
        tampered_amount = "1000.00"
        
        canon_orig = build_canonical_intent("veil-alice", "veil-bob", original_amount, "USD", "Payment", "nonce1", "2026-11-08T12:00:00Z")
        canon_tamp = build_canonical_intent("veil-alice", "veil-bob", tampered_amount, "USD", "Payment", "nonce1", "2026-11-08T12:00:00Z")
        
        _, orig_hash = compute_intent_hash(canonical_intent_bytes(canon_orig))
        _, tamp_hash = compute_intent_hash(canonical_intent_bytes(canon_tamp))

        return jsonify({
            "attack_type": "tamper_amount",
            "blocked": True,
            "status": "BLOCKED_BY_CRYPTOGRAPHIC_BINDING",
            "http_status": 400,
            "original_amount": original_amount,
            "tampered_amount": tampered_amount,
            "original_hash": orig_hash,
            "tampered_hash": tamp_hash,
            "reason": "Passkey signature binds the exact SHA-256 intent hash. Altering the amount alters the hash, causing verification to fail cryptographically.",
            "technical_detail": f"Hash mismatch: expected {orig_hash[:16]}... but tampered intent produced {tamp_hash[:16]}..."
        }), 200

    return jsonify({"error": f"Unknown attack type '{attack_type}'"}), 400

