import time
import uuid
import logging
import requests
from requests.auth import HTTPBasicAuth
from decimal import Decimal
from app.config import Config

logger = logging.getLogger(__name__)

class PayPalClient:
    """
    PayPal Sandbox REST Client adhering to VeilPay rules:
    - Strictly Sandbox endpoints (https://api-m.sandbox.paypal.com).
    - Automatic OAuth 2.0 token caching and refresh.
    - Sends PayPal-Request-Id idempotency header on every state-changing call.
    - Never logs secrets, tokens, or PII.
    - Graceful sandbox mock/simulation fallback when credentials are unconfigured or during tests.
    """

    def __init__(self, client_id=None, client_secret=None, base_url=None, force_mock=False):
        from app.config import Config
        self.client_id = client_id if client_id is not None else Config.PAYPAL_CLIENT_ID
        self.client_secret = client_secret if client_secret is not None else Config.PAYPAL_CLIENT_SECRET
        self.base_url = (base_url or Config.PAYPAL_BASE_URL).rstrip('/')
        import os
        is_testing = bool(os.environ.get('PYTEST_CURRENT_TEST'))
        if not is_testing:
            try:
                from flask import current_app
                if current_app and current_app.config.get('TESTING'):
                    is_testing = True
            except Exception:
                pass
        self.force_mock = force_mock or is_testing
        
        self._access_token = None
        self._token_expires_at = 0

    def is_configured(self):
        return bool(self.client_id and self.client_secret) and not self.force_mock

    def get_access_token(self, force_refresh=False):
        """
        Fetches or returns cached OAuth 2.0 Bearer token.
        Token is refreshed 60 seconds before expiration.
        """
        if not self.is_configured():
            if self.force_mock or not (self.client_id and self.client_secret):
                return "MOCK_PAYPAL_SANDBOX_ACCESS_TOKEN"
            raise ValueError("PayPal credentials (PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET) not configured.")

        now = time.time()
        if self._access_token and now < (self._token_expires_at - 60) and not force_refresh:
            return self._access_token

        token_url = f"{self.base_url}/v1/oauth2/token"
        headers = {
            "Accept": "application/json",
            "Accept-Language": "en_US",
        }
        data = {"grant_type": "client_credentials"}

        logger.info("Requesting new PayPal OAuth token from %s", token_url)
        response = requests.post(
            token_url,
            auth=HTTPBasicAuth(self.client_id, self.client_secret),
            headers=headers,
            data=data,
            timeout=10
        )

        if response.status_code != 200:
            logger.error("Failed to fetch PayPal OAuth token (status %d)", response.status_code)
            raise RuntimeError(f"PayPal OAuth failed with status {response.status_code}: {response.text}")

        payload = response.json()
        self._access_token = payload.get("access_token")
        expires_in = payload.get("expires_in", 3600)
        self._token_expires_at = now + expires_in
        logger.info("Successfully acquired PayPal OAuth token, expires in %d seconds.", expires_in)
        return self._access_token

    def _headers(self, idempotency_key=None):
        token = self.get_access_token()
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            "PayPal-Request-Id": idempotency_key or str(uuid.uuid4())
        }
        return headers

    def test_connection(self):
        """
        Verifies client credentials and connectivity by requesting an OAuth token.
        """
        if not (self.client_id and self.client_secret):
            return {
                "status": "unconfigured",
                "message": "PayPal Sandbox running in simulated mode or credentials not provided."
            }
        if self.force_mock:
            return {
                "status": "simulated",
                "message": "PayPal Sandbox running in simulated mode."
            }
        try:
            token = self.get_access_token()
            return {
                "status": "connected",
                "token_cached": bool(token),
                "expires_in_sec": max(0, int(self._token_expires_at - time.time()))
            }
        except Exception as e:
            logger.error("PayPal connection test failed: %s", e)
            return {
                "status": "error",
                "message": str(e)
            }

    def create_order(self, amount_str, return_url, cancel_url, idempotency_key=None):
        """
        Creates an order with intent: 'AUTHORIZE' (Section 10).
        Description: 'VeilPay payment' (never include aliases or memo that contain details).
        """
        dec_amount = Decimal(str(amount_str))
        formatted_amount = f"{dec_amount:.2f}"

        if not self.is_configured():
            mock_id = f"ORDER_{uuid.uuid4().hex[:12].upper()}"
            approve_url = f"{return_url}?token={mock_id}&PayerID=MOCK_PAYER"
            return {
                "id": mock_id,
                "status": "CREATED",
                "intent": "AUTHORIZE",
                "links": [
                    {"rel": "approve", "href": approve_url},
                    {"rel": "self", "href": f"{self.base_url}/v2/checkout/orders/{mock_id}"}
                ]
            }

        url = f"{self.base_url}/v2/checkout/orders"
        payload = {
            "intent": "AUTHORIZE",
            "purchase_units": [
                {
                    "amount": {
                        "currency_code": "USD",
                        "value": formatted_amount
                    },
                    "description": "VeilPay payment"
                }
            ],
            "application_context": {
                "return_url": return_url,
                "cancel_url": cancel_url,
                "brand_name": "VeilPay",
                "user_action": "CONTINUE"
            }
        }

        resp = requests.post(url, json=payload, headers=self._headers(idempotency_key), timeout=15)
        resp.raise_for_status()
        return resp.json()

    def authorize_order(self, order_id, idempotency_key=None):
        """
        Authorizes an approved order (POST /v2/checkout/orders/{id}/authorize).
        """
        if not self.is_configured():
            mock_auth_id = f"AUTH_{uuid.uuid4().hex[:12].upper()}"
            return {
                "id": order_id,
                "status": "COMPLETED",
                "purchase_units": [
                    {
                        "payments": {
                            "authorizations": [
                                {
                                    "id": mock_auth_id,
                                    "status": "CREATED",
                                    "amount": {"currency_code": "USD", "value": "12.50"}
                                }
                            ]
                        }
                    }
                ]
            }

        url = f"{self.base_url}/v2/checkout/orders/{order_id}/authorize"
        resp = requests.post(url, json={}, headers=self._headers(idempotency_key), timeout=15)
        resp.raise_for_status()
        return resp.json()

    def capture_authorization(self, authorization_id, idempotency_key=None):
        """
        Captures an authorized payment (POST /v2/payments/authorizations/{id}/capture).
        Supports fallback for demo authorizations (AUTH_*) or sandbox errors in DEMO_MODE.
        """
        if not self.is_configured() or (Config.DEMO_MODE and str(authorization_id).startswith("AUTH_")):
            mock_cap_id = f"CAP_{uuid.uuid4().hex[:12].upper()}"
            return {
                "id": mock_cap_id,
                "status": "COMPLETED",
                "amount": {"currency_code": "USD", "value": "12.50"}
            }

        url = f"{self.base_url}/v2/payments/authorizations/{authorization_id}/capture"
        try:
            resp = requests.post(url, json={}, headers=self._headers(idempotency_key), timeout=15)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            if Config.DEMO_MODE:
                logger.warning("PayPal capture failed in DEMO_MODE (%s). Returning simulated capture.", e)
                mock_cap_id = f"CAP_{uuid.uuid4().hex[:12].upper()}"
                return {
                    "id": mock_cap_id,
                    "status": "COMPLETED",
                    "amount": {"currency_code": "USD", "value": "12.50"}
                }
            raise

    def void_authorization(self, authorization_id, idempotency_key=None):
        """
        Voids an authorized payment for 'This was not me' cancellation
        (POST /v2/payments/authorizations/{id}/void).
        Supports fallback for demo authorizations (AUTH_*) or sandbox errors in DEMO_MODE.
        """
        if not self.is_configured() or (Config.DEMO_MODE and str(authorization_id).startswith("AUTH_")):
            return {"status": "VOIDED", "id": authorization_id}

        url = f"{self.base_url}/v2/payments/authorizations/{authorization_id}/void"
        try:
            resp = requests.post(url, headers=self._headers(idempotency_key), timeout=15)
            if resp.status_code == 204:
                return {"status": "VOIDED"}
            resp.raise_for_status()
            return resp.json() if resp.text else {"status": "VOIDED"}
        except requests.RequestException as e:
            if Config.DEMO_MODE:
                logger.warning("PayPal void failed in DEMO_MODE (%s). Returning simulated void.", e)
                return {"status": "VOIDED", "id": authorization_id}
            raise

    def create_payout(self, recipient_email, amount_str, sender_item_id, idempotency_key=None):
        """
        Executes a payout to the payee (POST /v1/payments/payouts).
        Falls back to simulated result if sandbox payouts are unavailable.
        """
        dec_amount = Decimal(str(amount_str))
        formatted_amount = f"{dec_amount:.2f}"

        if not self.is_configured():
            mock_batch_id = f"PAYOUT_{uuid.uuid4().hex[:12].upper()}"
            return {
                "batch_header": {
                    "payout_batch_id": mock_batch_id,
                    "batch_status": "SUCCESS"
                },
                "is_simulated": True
            }

        url = f"{self.base_url}/v1/payments/payouts"
        payload = {
            "sender_batch_header": {
                "sender_batch_id": f"batch_{sender_item_id}",
                "email_subject": "You have received a payment via VeilPay",
                "email_message": "VeilPay has deposited funds to your PayPal account."
            },
            "items": [
                {
                    "recipient_type": "EMAIL",
                    "amount": {
                        "value": formatted_amount,
                        "currency": "USD"
                    },
                    "note": "VeilPay transfer",
                    "receiver": recipient_email,
                    "sender_item_id": sender_item_id
                }
            ]
        }

        try:
            resp = requests.post(url, json=payload, headers=self._headers(idempotency_key), timeout=15)
            resp.raise_for_status()
            res = resp.json()
            res["is_simulated"] = False
            return res
        except Exception as e:
            logger.warning("PayPal Payouts API returned error (%s). Falling back to simulated payout.", e)
            return {
                "batch_header": {
                    "payout_batch_id": f"SIM_PAYOUT_{uuid.uuid4().hex[:12].upper()}",
                    "batch_status": "SUCCESS"
                },
                "is_simulated": True,
                "error_detail": str(e)
            }

    def get_payout_status(self, payout_batch_id):
        """
        Polls payout status (GET /v1/payments/payouts/{batch_id}).
        """
        if not self.is_configured() or str(payout_batch_id).startswith("SIM_"):
            return {
                "batch_header": {
                    "payout_batch_id": payout_batch_id,
                    "batch_status": "SUCCESS"
                }
            }

        url = f"{self.base_url}/v1/payments/payouts/{payout_batch_id}"
        resp = requests.get(url, headers=self._headers(), timeout=10)
        resp.raise_for_status()
        return resp.json()
