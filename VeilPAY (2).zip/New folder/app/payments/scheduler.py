import logging
from apscheduler.schedulers.background import BackgroundScheduler
from app.db import get_db
from app.payments.service import process_expired_holds

logger = logging.getLogger(__name__)

_scheduler = None

def init_scheduler(app=None):
    """
    Initializes and starts the APScheduler background job running every 15 seconds (Section 10, Step 6).
    """
    global _scheduler
    if _scheduler is not None and _scheduler.running:
        return _scheduler

    scheduler = BackgroundScheduler(daemon=True)

    def job_tick():
        try:
            db = get_db()
            processed = process_expired_holds(db)
            if processed:
                logger.info("APScheduler hold-expiry job processed %d intents: %s", len(processed), processed)
        except Exception as e:
            logger.error("Error running hold-expiry job: %s", e)

    scheduler.add_job(
        func=job_tick,
        trigger="interval",
        seconds=15,
        id="hold_expiry_capture_job",
        replace_existing=True
    )

    scheduler.start()
    _scheduler = scheduler
    logger.info("APScheduler initialized: hold-expiry capture job running every 15s.")
    return _scheduler

def stop_scheduler():
    """Stops the scheduler on shutdown or during tests."""
    global _scheduler
    if _scheduler is not None and _scheduler.running:
        _scheduler.shutdown(wait=False)
        _scheduler = None

