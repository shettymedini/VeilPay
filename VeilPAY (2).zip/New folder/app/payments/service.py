import datetime
import logging
from bson import ObjectId
from app.config import Config
from app.security import decrypt_field
from app.ledger.ledger import append_ledger_entry
from app.paypal.client import PayPalClient

logger = logging.getLogger(__name__)

def initiate_paypal_order(db, intent_id: str, user_id: str, origin: str, paypal_client: PayPalClient = None) -> tuple[str, str]:
    """
    Step 3 of payment lifecycle (Section 10):
    Creates PayPal order with intent: 'AUTHORIZE' (POST /v2/checkout/orders).
    Description: 'VeilPay payment' (strictly excludes aliases and notes).
    Returns (approval_url, order_id).
    """
    paypal = paypal_client or PayPalClient()
    intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    if not intent:
        raise ValueError("Payment intent not found.")

    if str(intent["payer_id"]) != str(user_id):
        raise PermissionError("Only the payer can initiate PayPal checkout.")

    if intent["status"] != "AWAITING_PAYPAL_APPROVAL":
        raise ValueError(f"Intent in state '{intent['status']}' cannot initiate PayPal checkout.")

    return_url = f"{origin}/payments/{intent_id}/paypal/return"
    cancel_url = f"{origin}/payments/{intent_id}/paypal/cancel"

    order_res = paypal.create_order(
        amount_str=intent["amount"],
        return_url=return_url,
        cancel_url=cancel_url,
        idempotency_key=f"order_{intent['_id']}"
    )

    order_id = order_res.get("id")
    approval_url = None
    for link in order_res.get("links", []):
        if link.get("rel") == "approve":
            approval_url = link.get("href")
            break

    if not approval_url:
        approval_url = f"{return_url}?token={order_id}"

    # Update intent paypal details
    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "paypal.order_id": order_id,
                "updated_at": datetime.datetime.now(datetime.timezone.utc)
            }
        }
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYPAL_ORDER_CREATED",
        data={"order_id": order_id, "amount": intent["amount"]}
    )

    return approval_url, order_id

def authorize_paypal_return(db, intent_id: str, user_id: str, paypal_client: PayPalClient = None) -> dict:
    """
    Step 4 of payment lifecycle (Section 10):
    On return from PayPal, authorizes the order (POST /v2/checkout/orders/{id}/authorize).
    Sets hold_until = now + hold_seconds(tier). Status AUTHORIZED_HOLD.
    """
    paypal = paypal_client or PayPalClient()
    intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    if not intent:
        raise ValueError("Payment intent not found.")

    if str(intent["payer_id"]) != str(user_id):
        raise PermissionError("Access denied.")

    # Idempotent return check
    if intent["status"] == "AUTHORIZED_HOLD":
        return intent

    if intent["status"] != "AWAITING_PAYPAL_APPROVAL":
        raise ValueError(f"Cannot authorize intent with status '{intent['status']}'.")

    order_id = intent.get("paypal", {}).get("order_id")
    if not order_id:
        import uuid
        try:
            order_res = paypal.create_order(
                amount_str=intent["amount"],
                return_url="http://localhost:5000",
                cancel_url="http://localhost:5000",
                idempotency_key=f"order_{intent['_id']}"
            )
            order_id = order_res.get("id")
        except Exception as e:
            logger.warning("Could not create PayPal order for quick-authorize: %s", e)
            order_id = f"ORDER_{uuid.uuid4().hex[:12].upper()}"

        if not order_id:
            order_id = f"ORDER_{uuid.uuid4().hex[:12].upper()}"

        db.payment_intents.update_one(
            {"_id": intent["_id"]},
            {"$set": {"paypal.order_id": order_id}}
        )

    try:
        auth_res = paypal.authorize_order(order_id, idempotency_key=f"auth_{intent['_id']}")
    except Exception as e:
        if Config.DEMO_MODE or not paypal.is_configured():
            logger.info("Demo/fallback mode: Simulating buyer approval for order %s (%s)", order_id, e)
            auth_res = {
                "id": order_id,
                "status": "COMPLETED",
                "purchase_units": [{
                    "payments": {
                        "authorizations": [{
                            "id": f"AUTH_{order_id}",
                            "status": "CREATED",
                            "amount": {"currency_code": "USD", "value": str(intent["amount"])}
                        }]
                    }
                }]
            }
        else:
            raise
    
    # Extract authorization ID from PayPal response
    authorization_id = None
    try:
        units = auth_res.get("purchase_units", [])
        if units:
            auths = units[0].get("payments", {}).get("authorizations", [])
            if auths:
                authorization_id = auths[0].get("id")
    except Exception as e:
        logger.warning("Could not extract authorization_id from response: %s", e)

    if not authorization_id:
        authorization_id = f"AUTH_{order_id}"

    # Determine hold duration from risk tier (Section 10 & 11)
    tier = intent.get("risk", {}).get("tier", "LOW")
    if tier == "LOW":
        hold_seconds = Config.LOW_HOLD_SECONDS
    else:
        hold_seconds = Config.MEDIUM_HOLD_SECONDS

    now = datetime.datetime.now(datetime.timezone.utc)
    hold_until = now + datetime.timedelta(seconds=hold_seconds)

    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "AUTHORIZED_HOLD",
                "paypal.authorization_id": authorization_id,
                "hold_until": hold_until,
                "updated_at": now
            }
        }
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYMENT_AUTHORIZED_HOLD",
        data={
            "authorization_id": authorization_id,
            "tier": tier,
            "hold_seconds": hold_seconds,
            "hold_until": hold_until.isoformat()
        }
    )

    return db.payment_intents.find_one({"_id": intent["_id"]})

def void_authorized_payment(db, intent_id: str, user_id: str, reason: str = "This was not me", paypal_client: PayPalClient = None) -> dict:
    """
    Step 5 of payment lifecycle:
    During the hold the payer presses 'This was not me'.
    Calls POST /v2/payments/authorizations/{id}/void and sets CANCELLED_BY_PAYER (Section 10).
    """
    paypal = paypal_client or PayPalClient()
    intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    if not intent:
        raise ValueError("Payment intent not found.")

    if str(intent["payer_id"]) != str(user_id):
        raise PermissionError("Only the payer can void this transaction.")

    if intent["status"] != "AUTHORIZED_HOLD":
        raise ValueError(f"Cannot void payment in state '{intent['status']}'. Hold expired or already captured.")

    authorization_id = intent.get("paypal", {}).get("authorization_id")
    if authorization_id:
        paypal.void_authorization(authorization_id, idempotency_key=f"void_{intent['_id']}")

    now = datetime.datetime.now(datetime.timezone.utc)
    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "CANCELLED_BY_PAYER",
                "hold_until": None,
                "updated_at": now
            }
        }
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYMENT_VOIDED_BY_PAYER",
        data={
            "reason": reason,
            "authorization_id": authorization_id,
            "voided_by": intent["payer_alias"]
        }
    )

    return db.payment_intents.find_one({"_id": intent["_id"]})

def capture_and_payout(db, intent_id: str, paypal_client: PayPalClient = None) -> dict:
    """
    Steps 6 & 7 of payment lifecycle:
    Captures authorized payment after hold expiration, then dispatches payout to payee (Section 10).
    AUTHORIZED_HOLD -> CAPTURED -> PAYOUT_SENT -> COMPLETED
    """
    paypal = paypal_client or PayPalClient()
    intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    if not intent:
        raise ValueError("Payment intent not found.")

    if intent["status"] != "AUTHORIZED_HOLD":
        return intent

    authorization_id = intent.get("paypal", {}).get("authorization_id")
    if not authorization_id:
        raise ValueError("Missing authorization_id on intent.")

    now = datetime.datetime.now(datetime.timezone.utc)

    # 1. Capture payment
    cap_res = paypal.capture_authorization(authorization_id, idempotency_key=f"cap_{intent['_id']}")
    capture_id = cap_res.get("id", f"CAP_{authorization_id}")

    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "CAPTURED",
                "paypal.capture_id": capture_id,
                "hold_until": None,
                "updated_at": now
            }
        }
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYMENT_CAPTURED",
        data={"authorization_id": authorization_id, "capture_id": capture_id, "amount": intent["amount"]}
    )

    # 2. Payout to payee via decrypted payout_email
    payee = db.users.find_one({"_id": intent["payee_id"]})
    payout_email = decrypt_field(payee.get("payout_email_enc", "")) if payee else None

    if not payout_email:
        payout_email = "sandbox_payee@veilpay.test"

    payout_res = paypal.create_payout(
        recipient_email=payout_email,
        amount_str=intent["amount"],
        sender_item_id=str(intent["_id"]),
        idempotency_key=f"payout_{intent['_id']}"
    )

    batch_header = payout_res.get("batch_header", {})
    payout_batch_id = batch_header.get("payout_batch_id")
    is_simulated = payout_res.get("is_simulated", False)

    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "PAYOUT_SENT",
                "paypal.payout_batch_id": payout_batch_id,
                "updated_at": now
            }
        }
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYOUT_SENT",
        data={
            "payout_batch_id": payout_batch_id,
            "is_simulated": is_simulated,
            "payee_alias": intent["payee_alias"]
        }
    )

    # 3. Mark completed
    completed_time = datetime.datetime.now(datetime.timezone.utc)
    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "COMPLETED",
                "updated_at": completed_time
            }
        }
    )

    # Mark first_paid_at in payer's address book if contact exists
    db.contacts.update_one(
        {"owner_id": intent["payer_id"], "alias": intent["payee_alias"], "first_paid_at": None},
        {"$set": {"first_paid_at": completed_time}}
    )

    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYMENT_COMPLETED",
        data={"amount": intent["amount"], "payee_alias": intent["payee_alias"]}
    )

    return db.payment_intents.find_one({"_id": intent["_id"]})

def process_expired_holds(db, paypal_client: PayPalClient = None) -> list[str]:
    """
    APScheduler job (Section 10, Step 6):
    Finds intents whose hold_until has passed and captures them.
    Also purges or expires abandoned unsigned intents.
    Returns list of processed intent IDs.
    """
    now = datetime.datetime.now(datetime.timezone.utc)
    query = {
        "status": "AUTHORIZED_HOLD",
        "hold_until": {"$lte": now}
    }
    due_intents = list(db.payment_intents.find(query))
    processed = []

    for intent in due_intents:
        try:
            capture_and_payout(db, intent["_id"], paypal_client=paypal_client)
            processed.append(str(intent["_id"]))
            logger.info("Successfully captured & paid out intent %s after hold expiration.", intent["_id"])
        except Exception as e:
            logger.error("Failed to capture intent %s: %s", intent["_id"], e)

    # Expire unsigned intents older than TTL
    db.payment_intents.update_many(
        {"status": "AWAITING_SIGNATURE", "expires_at": {"$lte": now}},
        {"$set": {"status": "EXPIRED", "updated_at": now}}
    )

    return processed

