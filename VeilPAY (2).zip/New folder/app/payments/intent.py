import hashlib
import json
from decimal import Decimal, InvalidOperation

def format_amount(amount) -> str:
    """
    Formats amount strictly as 2-decimal string (Rule 5: Money is never a float).
    """
    if isinstance(amount, float):
        raise ValueError("Float amounts are forbidden by VeilPay spec. Use Decimal or string.")
    dec = Decimal(str(amount))
    if dec <= 0:
        raise ValueError("Amount must be greater than zero.")
    return f"{dec:.2f}"

def build_canonical_intent(payer_alias: str, payee_alias: str, amount_str: str, currency: str, memo_masked: str, nonce: str, expires_at_iso: str) -> dict:
    """
    Constructs the canonical intent dictionary:
    {payer_alias, payee_alias, amount, currency, memo_masked, nonce, expires_at} (Section 9).
    """
    return {
        "amount": format_amount(amount_str),
        "currency": currency or "USD",
        "expires_at": expires_at_iso,
        "memo_masked": memo_masked or "",
        "nonce": nonce,
        "payee_alias": payee_alias,
        "payer_alias": payer_alias
    }

def canonical_intent_bytes(intent_dict: dict) -> bytes:
    """
    Serializes canonical intent with sorted keys and no whitespace (Section 9).
    """
    canonical_str = json.dumps(intent_dict, sort_keys=True, separators=(',', ':'))
    return canonical_str.encode('utf-8')

def compute_intent_hash(canonical_bytes: bytes) -> tuple[bytes, str]:
    """
    Computes intent_hash = SHA256(canonical_intent).
    Returns (raw_32_bytes, hex_string).
    The raw bytes are used as the WebAuthn challenge.
    """
    digest_bytes = hashlib.sha256(canonical_bytes).digest()
    digest_hex = digest_bytes.hex()
    return digest_bytes, digest_hex

