import re
import secrets
import datetime
from decimal import Decimal, InvalidOperation
from flask import Blueprint, request, jsonify, session
from bson import ObjectId
import webauthn
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes

from app.db import get_db
from app.config import Config
from app.security import require_login, require_csrf, rate_limit
from app.users.alias import is_valid_alias
from app.risk.pii import scrub_pii, scrub_pii_regex
from app.risk.engine import evaluate_risk
from app.ledger.ledger import append_ledger_entry
from app.payments.intent import (
    build_canonical_intent,
    canonical_intent_bytes,
    compute_intent_hash,
    format_amount
)
from app.auth.webauthn_service import (
    store_challenge,
    get_and_consume_challenge,
    generate_authentication_options_for_user,
    verify_authentication
)

payments_bp = Blueprint('payments', __name__, url_prefix='/payments')

def serialize_intent_view(intent_doc: dict, current_user_id: str) -> dict:
    """
    Serializes payment intent for user view.
    Privacy Invariant: Only aliases are exposed. Never emails, phones, or PayPal IDs.
    """
    is_payer = str(intent_doc["payer_id"]) == str(current_user_id)
    return {
        "id": str(intent_doc["_id"]),
        "payer_alias": intent_doc["payer_alias"],
        "payee_alias": intent_doc["payee_alias"],
        "amount": intent_doc["amount"],
        "currency": intent_doc.get("currency", "USD"),
        "memo_masked": intent_doc.get("memo_masked", ""),
        "status": intent_doc["status"],
        "risk": intent_doc.get("risk", {}),
        "expires_at": intent_doc["expires_at"].isoformat() if intent_doc.get("expires_at") else None,
        "signed_at": intent_doc["signed_at"].isoformat() if intent_doc.get("signed_at") else None,
        "hold_until": intent_doc["hold_until"].isoformat() if intent_doc.get("hold_until") else None,
        "created_at": intent_doc["created_at"].isoformat() if intent_doc.get("created_at") else None,
        "is_payer": is_payer
    }

@payments_bp.route('/intent', methods=['POST'])
@require_login
@require_csrf
def create_intent():
    """
    Step 1: Create payment intent.
    - Validate alias exists & is not self
    - Validate amount against limits
    - Scrub memo for PII
    - Compute deterministic risk score
    - Build canonical intent & intent_hash (Section 9 & 10)
    """
    db = get_db()
    user_id = session.get('user_id')
    payer = db.users.find_one({"_id": ObjectId(user_id)})
    if not payer:
        return jsonify({"error": "Payer account not found."}), 404

    data = request.get_json() or {}
    raw_payee = str(data.get('payee_alias', '')).strip()
    raw_amount = data.get('amount')
    memo = str(data.get('memo', '')).strip()

    if not raw_payee:
        return jsonify({"error": "Recipient name, contact, or alias is required."}), 400

    clean_payee = raw_payee.lstrip('@')
    clean_lower = clean_payee.lower()
    payee = None

    # 1. Check payer's address book contacts first (by nickname or alias)
    contact = db.contacts.find_one({
        "owner_id": ObjectId(user_id),
        "$or": [
            {"nickname": {"$regex": f"^{re.escape(clean_payee)}$", "$options": "i"}},
            {"alias": clean_lower}
        ]
    })
    if contact:
        payee = db.users.find_one({"alias": contact["alias"], "status": "active"})

    # 2. Check all users by public display_name (e.g. 'green', 'apple')
    if not payee:
        payee = db.users.find_one({
            "display_name": {"$regex": f"^{re.escape(clean_payee)}$", "$options": "i"},
            "status": "active"
        })

    # 3. Check all users by exact alias
    if not payee and is_valid_alias(clean_lower):
        payee = db.users.find_one({"alias": clean_lower, "status": "active"})

    # 4. In demo mode, if recipient doesn't exist, create a demo friend so payments work smoothly
    if not payee and (Config.DEMO_MODE or os.environ.get("FLASK_ENV") != "production"):
        from app.users.alias import create_unique_alias
        new_alias = create_unique_alias(db)
        payee = {
            "alias": new_alias,
            "display_name": clean_payee,
            "limits": {"per_payment": "200.00", "per_day": "500.00", "per_payee_default": "100.00"},
            "new_payee_cooling_hours": 24,
            "status": "active",
            "created_at": datetime.datetime.now(datetime.timezone.utc)
        }
        db.users.insert_one(payee)

    if not payee:
        return jsonify({"error": f"No active recipient found for '{raw_payee}'. Please check their public name or alias."}), 404

    payee_alias = payee["alias"]

    if payee_alias == payer['alias']:
        return jsonify({"error": "You cannot send a payment to yourself."}), 400

    # 2. Validate amount (Rule 5: Money is never float)
    try:
        amount_str = format_amount(raw_amount)
        amount_dec = Decimal(amount_str)
    except (ValueError, InvalidOperation, TypeError) as e:
        return jsonify({"error": f"Invalid payment amount: {str(e)}"}), 400

    # 3. Scrub memo for PII (Section 12)
    memo_masked, pii_found, memo_flags = scrub_pii(memo)

    # 4. Evaluate Risk & Hard limits (Section 11)
    risk_res = evaluate_risk(
        db,
        payer_doc=payer,
        payee_doc=payee,
        amount_dec=amount_dec,
        raw_memo=memo,
        memo_flags=memo_flags
    )

    now = datetime.datetime.now(datetime.timezone.utc)
    expires_at = now + datetime.timedelta(seconds=Config.INTENT_TTL_SECONDS)
    nonce = secrets.token_hex(16)

    # 5. Build Canonical Intent & Hash (Section 9)
    canonical_dict = build_canonical_intent(
        payer_alias=payer['alias'],
        payee_alias=payee['alias'],
        amount_str=amount_str,
        currency="USD",
        memo_masked=memo_masked,
        nonce=nonce,
        expires_at_iso=expires_at.isoformat()
    )
    canon_bytes = canonical_intent_bytes(canonical_dict)
    intent_hash_bytes, intent_hash_hex = compute_intent_hash(canon_bytes)

    status = "BLOCKED" if risk_res["is_blocked"] else "AWAITING_SIGNATURE"

    intent_doc = {
        "payer_id": payer["_id"],
        "payee_id": payee["_id"],
        "payer_alias": payer["alias"],
        "payee_alias": payee["alias"],
        "amount": amount_str,
        "currency": "USD",
        "memo_masked": memo_masked,
        "memo_flags": memo_flags,
        "risk": {
            "score": risk_res["score"],
            "tier": risk_res["tier"],
            "reasons": risk_res["reasons"],
            "explanation": risk_res["explanation"]
        },
        "canonical_intent": canonical_dict,
        "intent_hash": intent_hash_hex,
        "nonce": nonce,
        "expires_at": expires_at,
        "signed_at": None,
        "status": status,
        "paypal": {
            "order_id": None,
            "authorization_id": None,
            "capture_id": None,
            "payout_batch_id": None
        },
        "hold_until": None,
        "created_at": now,
        "updated_at": now
    }

    result = db.payment_intents.insert_one(intent_doc)
    intent_id = result.inserted_id
    intent_doc["_id"] = intent_id

    # Append to append-only tamper-evident ledger (Section 10, Step 8)
    append_ledger_entry(
        db,
        intent_id=intent_id,
        event="PAYMENT_INTENT_CREATED",
        data={
            "payer_alias": payer["alias"],
            "payee_alias": payee["alias"],
            "amount": amount_str,
            "status": status,
            "intent_hash": intent_hash_hex
        }
    )

    if risk_res["is_blocked"]:
        return jsonify({
            "status": "BLOCKED",
            "error": risk_res["block_reason"],
            "intent": serialize_intent_view(intent_doc, user_id)
        }), 403

    return jsonify({
        "status": "ok",
        "payment_status": status,
        "intent": serialize_intent_view(intent_doc, user_id)
    }), 201

@payments_bp.route('/<intent_id>/sign/begin', methods=['POST'])
@require_login
def sign_begin(intent_id):
    """
    Step 2: Get signing challenge.
    The WebAuthn challenge is EXACTLY intent_hash (bytes) (Section 9, Step 3).
    """
    db = get_db()
    user_id = session.get('user_id')

    try:
        intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    except Exception:
        return jsonify({"error": "Invalid intent ID format."}), 400

    if not intent:
        return jsonify({"error": "Payment intent not found."}), 404

    if str(intent["payer_id"]) != str(user_id):
        return jsonify({"error": "Only the payer can sign this transaction."}), 403

    if intent["status"] != "AWAITING_SIGNATURE":
        return jsonify({"error": f"Intent cannot be signed in state '{intent['status']}'."}), 400

    now = datetime.datetime.now(datetime.timezone.utc)
    expires_at = intent["expires_at"]
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=datetime.timezone.utc)
    if now > expires_at:
        db.payment_intents.update_one({"_id": intent["_id"]}, {"$set": {"status": "EXPIRED"}})
        return jsonify({"error": "Payment intent has expired (5-minute TTL)."}), 400

    # Challenge is exactly the SHA256 intent_hash bytes
    intent_hash_bytes = bytes.fromhex(intent["intent_hash"])

    # Look up registered credentials for payer
    credentials = list(db.credentials.find({"user_id": ObjectId(user_id)}))
    if not credentials:
        return jsonify({"error": "No registered passkey found for this account."}), 400

    try:
        options, challenge_bytes = generate_authentication_options_for_user(
            allowed_credentials=credentials,
            custom_challenge_bytes=intent_hash_bytes
        )

        challenge_doc_id = store_challenge(
            db,
            user_or_session_id=str(user_id),
            purpose="sign",
            challenge_bytes=intent_hash_bytes,
            intent_id=str(intent["_id"]),
            ttl_seconds=Config.INTENT_TTL_SECONDS
        )
        session[f'sign_challenge_{intent_id}'] = challenge_doc_id

        return webauthn.options_to_json(options), 200, {'Content-Type': 'application/json'}
    except Exception as e:
        return jsonify({"error": f"Failed to begin signing: {str(e)}"}), 500

@payments_bp.route('/<intent_id>/sign', methods=['POST'])
@require_login
@require_csrf
def sign_finish(intent_id):
    """
    Step 3: Verify passkey signature over intent_hash.
    - Consumes challenge (replay prevention)
    - Verifies biometric/PIN assertion
    - Binds amount and payee (Section 9, Step 5)
    """
    db = get_db()
    user_id = session.get('user_id')

    try:
        intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    except Exception:
        return jsonify({"error": "Invalid intent ID format."}), 400

    if not intent:
        return jsonify({"error": "Payment intent not found."}), 404

    if str(intent["payer_id"]) != str(user_id):
        return jsonify({"error": "Only the payer can sign this transaction."}), 403

    if intent["status"] != "AWAITING_SIGNATURE":
        return jsonify({"error": f"Cannot sign intent with status '{intent['status']}'."}), 400

    now = datetime.datetime.now(datetime.timezone.utc)
    expires_at = intent["expires_at"]
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=datetime.timezone.utc)
    if now > expires_at:
        db.payment_intents.update_one({"_id": intent["_id"]}, {"$set": {"status": "EXPIRED"}})
        return jsonify({"error": "Payment intent has expired."}), 400

    data = request.get_json() or {}
    credential_payload = data.get('credential')
    if not credential_payload:
        return jsonify({"error": "Missing WebAuthn credential payload."}), 400

    # Retrieve and consume signing challenge
    challenge_doc_id = session.pop(f'sign_challenge_{intent_id}', None) or data.get('challenge_id')
    expected_challenge = None
    if challenge_doc_id:
        expected_challenge = get_and_consume_challenge(db, challenge_doc_id, expected_purpose="sign")
    else:
        # Fallback challenge lookup by intent_id
        challenge_doc = db.webauthn_challenges.find_one_and_delete({
            "intent_id": str(intent["_id"]),
            "purpose": "sign"
        })
        if challenge_doc:
            expected_challenge = base64url_to_bytes(challenge_doc["challenge_b64url"])

    if not expected_challenge:
        return jsonify({"error": "Signing challenge missing, expired, or already consumed (replay rejected)."}), 400

    # Re-verify that stored challenge matches the intent_hash bytes exactly
    intent_hash_bytes = bytes.fromhex(intent["intent_hash"])
    if expected_challenge != intent_hash_bytes:
        return jsonify({"error": "Challenge mismatch with canonical intent hash."}), 400

    # Look up credential
    cred_id = credential_payload.get('id')
    cred_doc = db.credentials.find_one({
        "credential_id": cred_id,
        "user_id": ObjectId(user_id)
    })
    if not cred_doc:
        return jsonify({"error": "Passkey credential does not belong to this payer."}), 401

    # Verify passkey signature
    try:
        verified_auth = verify_authentication(
            credential_data=credential_payload,
            expected_challenge_bytes=intent_hash_bytes,
            public_key_bytes=cred_doc["public_key"],
            current_sign_count=cred_doc.get("sign_count", 0)
        )
    except Exception as e:
        return jsonify({"error": f"Cryptographic signature verification failed: {str(e)}"}), 400

    # Update credential sign count
    db.credentials.update_one(
        {"_id": cred_doc["_id"]},
        {
            "$set": {
                "sign_count": verified_auth.new_sign_count,
                "last_used_at": now
            }
        }
    )

    # Advance state machine: AWAITING_SIGNATURE -> AWAITING_PAYPAL_APPROVAL (Section 10)
    db.payment_intents.update_one(
        {"_id": intent["_id"]},
        {
            "$set": {
                "status": "AWAITING_PAYPAL_APPROVAL",
                "signed_at": now,
                "updated_at": now
            }
        }
    )

    # Append to append-only tamper-evident ledger (Section 10, Step 8)
    append_ledger_entry(
        db,
        intent_id=intent["_id"],
        event="PAYMENT_INTENT_SIGNED",
        data={
            "signer_alias": intent["payer_alias"],
            "intent_hash": intent["intent_hash"],
            "new_sign_count": verified_auth.new_sign_count
        }
    )

    updated_intent = db.payment_intents.find_one({"_id": intent["_id"]})
    return jsonify({
        "status": "ok",
        "message": "Payment intent signed with passkey.",
        "payment_status": "AWAITING_PAYPAL_APPROVAL",
        "intent": serialize_intent_view(updated_intent, user_id)
    }), 200

@payments_bp.route('/<intent_id>', methods=['GET'])
@require_login
def get_intent_status(intent_id):
    """
    Returns payment status, countdown, explanation.
    Access strictly restricted to payer or payee (Section 13).
    """
    db = get_db()
    user_id = session.get('user_id')

    try:
        intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
    except Exception:
        return jsonify({"error": "Invalid intent ID format."}), 400

    if not intent:
        return jsonify({"error": "Payment intent not found."}), 404

    # Authorization check
    if str(intent["payer_id"]) != str(user_id) and str(intent["payee_id"]) != str(user_id):
        return jsonify({"error": "Access denied."}), 403

    return jsonify({
        "status": "ok",
        "intent": serialize_intent_view(intent, user_id)
    }), 200

@payments_bp.route('/<intent_id>/paypal/start', methods=['GET', 'POST'])
@require_login
def paypal_start(intent_id):
    """
    Creates PayPal order with intent: 'AUTHORIZE' and returns/redirects to approval URL (Section 10).
    """
    db = get_db()
    user_id = session.get('user_id')
    origin = request.host_url.rstrip('/')

    try:
        from app.payments.service import initiate_paypal_order
        approval_url, order_id = initiate_paypal_order(db, intent_id, user_id, origin)
        
        if request.is_json or request.args.get('format') == 'json':
            return jsonify({
                "status": "ok",
                "approval_url": approval_url,
                "order_id": order_id
            }), 200
        from flask import redirect
        return redirect(approval_url)
    except Exception as e:
        return jsonify({"error": f"Failed to initiate PayPal checkout: {str(e)}"}), 400

@payments_bp.route('/<intent_id>/paypal/return', methods=['GET', 'POST'])
@require_login
def paypal_return(intent_id):
    """
    On return from PayPal approval, authorizes the order and starts the hold countdown (Section 10, Step 4).
    """
    db = get_db()
    user_id = session.get('user_id')

    try:
        from app.payments.service import authorize_paypal_return
        updated_intent = authorize_paypal_return(db, intent_id, user_id)
        
        if request.is_json or request.args.get('format') == 'json':
            return jsonify({
                "status": "ok",
                "payment_status": updated_intent["status"],
                "hold_until": updated_intent["hold_until"].isoformat() if updated_intent.get("hold_until") else None,
                "intent": serialize_intent_view(updated_intent, user_id)
            }), 200
        from flask import redirect
        return redirect(f"/status?intent_id={intent_id}")
    except Exception as e:
        return jsonify({"error": f"Failed to authorize payment: {str(e)}"}), 400

@payments_bp.route('/<intent_id>/paypal/cancel', methods=['GET'])
@require_login
def paypal_cancel(intent_id):
    """
    Payer cancelled on PayPal approval screen.
    """
    from flask import redirect
    return redirect(f"/status?intent_id={intent_id}&cancelled=1")

@payments_bp.route('/<intent_id>/void', methods=['POST'])
@require_login
@require_csrf
def void_payment_endpoint(intent_id):
    """
    Step 5: 'This was not me' during hold window.
    Calls POST /v2/payments/authorizations/{id}/void and sets CANCELLED_BY_PAYER (Section 10).
    """
    db = get_db()
    user_id = session.get('user_id')
    data = request.get_json() or {}
    reason = data.get("reason", "This was not me")

    try:
        from app.payments.service import void_authorized_payment
        voided_intent = void_authorized_payment(db, intent_id, user_id, reason=reason)
        return jsonify({
            "status": "ok",
            "message": "Payment voided successfully. Funds will not be captured.",
            "payment_status": voided_intent["status"],
            "intent": serialize_intent_view(voided_intent, user_id)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Failed to void payment: {str(e)}"}), 400

@payments_bp.route('/<intent_id>/capture', methods=['POST'])
@require_login
@require_csrf
def capture_payment_endpoint(intent_id):
    """
    Direct capture trigger on hold expiration or fast-settle bypass.
    Executes capture_and_payout and returns completed status without reload loops.
    """
    db = get_db()
    user_id = session.get('user_id')
    try:
        from app.payments.service import capture_and_payout
        intent = db.payment_intents.find_one({"_id": ObjectId(intent_id)})
        if not intent:
            return jsonify({"error": "Payment intent not found."}), 404
        if str(intent["payer_id"]) != str(user_id) and str(intent.get("payee_id")) != str(user_id):
            return jsonify({"error": "Unauthorized access."}), 403

        if intent["status"] in ["COMPLETED", "PAYOUT_SENT"]:
            return jsonify({
                "status": "ok",
                "message": "Payment already completed.",
                "payment_status": "COMPLETED",
                "intent": serialize_intent_view(intent, user_id)
            }), 200

        updated_intent = capture_and_payout(db, intent_id)
        return jsonify({
            "status": "ok",
            "message": "Payment captured and paid out successfully.",
            "payment_status": updated_intent["status"],
            "intent": serialize_intent_view(updated_intent, user_id)
        }), 200
    except Exception as e:
        return jsonify({"error": f"Failed to capture payment: {str(e)}"}), 400

