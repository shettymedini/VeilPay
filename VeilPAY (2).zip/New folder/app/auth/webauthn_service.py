import os
import time
import datetime
import logging
from bson import ObjectId
import webauthn
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes
from webauthn.helpers.structs import (
    AuthenticatorSelectionCriteria,
    UserVerificationRequirement,
    ResidentKeyRequirement,
    PublicKeyCredentialDescriptor,
    PublicKeyCredentialType,
    AuthenticatorTransport
)
from app.config import Config

logger = logging.getLogger(__name__)

def store_challenge(db, user_or_session_id: str, purpose: str, challenge_bytes: bytes, intent_id: str = None, ttl_seconds: int = 300) -> str:
    """
    Stores a WebAuthn challenge with a TTL expiry in MongoDB.
    Returns the challenge document ID as a string.
    """
    expires_at = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=ttl_seconds)
    doc = {
        "user_id_or_session": str(user_or_session_id),
        "purpose": purpose,
        "challenge_b64url": bytes_to_base64url(challenge_bytes),
        "intent_id": intent_id,
        "expires_at": expires_at,
        "created_at": datetime.datetime.now(datetime.timezone.utc)
    }
    result = db.webauthn_challenges.insert_one(doc)
    return str(result.inserted_id)

def get_and_consume_challenge(db, challenge_id: str, expected_purpose: str = None):
    """
    Retrieves and immediately removes a challenge to enforce single-use (replay prevention).
    Returns challenge bytes if valid, or None if missing or expired.
    """
    try:
        obj_id = ObjectId(challenge_id)
    except Exception:
        return None

    query = {"_id": obj_id}
    if expected_purpose:
        query["purpose"] = expected_purpose

    doc = db.webauthn_challenges.find_one_and_delete(query)
    if not doc:
        return None

    # Check expiration just in case TTL index didn't purge yet
    expires_at = doc.get("expires_at")
    if expires_at:
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=datetime.timezone.utc)
        if expires_at < datetime.datetime.now(datetime.timezone.utc):
            return None

    return base64url_to_bytes(doc["challenge_b64url"])

def generate_registration_options_for_user(user_email: str):
    """
    Generates WebAuthn registration options.
    userVerification: 'required', residentKey: 'preferred' (Section 9).
    """
    user_id = os.urandom(16)
    
    options = webauthn.generate_registration_options(
        rp_id=Config.RP_ID,
        rp_name=Config.RP_NAME,
        user_id=user_id,
        user_name=user_email,
        user_display_name=user_email.split('@')[0],
        authenticator_selection=AuthenticatorSelectionCriteria(
            user_verification=UserVerificationRequirement.REQUIRED,
            resident_key=ResidentKeyRequirement.PREFERRED
        )
    )
    return options, options.challenge

def verify_registration(credential_data, expected_challenge_bytes: bytes):
    """
    Verifies browser registration assertion using py_webauthn.
    """
    verified_registration = webauthn.verify_registration_response(
        credential=credential_data,
        expected_challenge=expected_challenge_bytes,
        expected_rp_id=Config.RP_ID,
        expected_origin=Config.ORIGIN,
        require_user_verification=True
    )
    return verified_registration

def generate_authentication_options_for_user(allowed_credentials=None, custom_challenge_bytes=None):
    """
    Generates WebAuthn authentication options.
    Supports discoverable credentials if allowed_credentials is None.
    Supports custom challenge (e.g., intent_hash for payment signing).
    """
    allow_descriptors = None
    if allowed_credentials:
        allow_descriptors = []
        for cred in allowed_credentials:
            cred_id_bytes = base64url_to_bytes(cred["credential_id"]) if isinstance(cred["credential_id"], str) else cred["credential_id"]
            transports = None
            if cred.get("transports"):
                transports = [AuthenticatorTransport(t) for t in cred["transports"] if t in AuthenticatorTransport.__members__.values()]
            allow_descriptors.append(PublicKeyCredentialDescriptor(
                type=PublicKeyCredentialType.PUBLIC_KEY,
                id=cred_id_bytes,
                transports=transports
            ))

    options = webauthn.generate_authentication_options(
        rp_id=Config.RP_ID,
        challenge=custom_challenge_bytes,
        allow_credentials=allow_descriptors,
        user_verification=UserVerificationRequirement.REQUIRED
    )
    return options, options.challenge

def verify_authentication(credential_data, expected_challenge_bytes: bytes, public_key_bytes: bytes, current_sign_count: int):
    """
    Verifies browser authentication assertion using py_webauthn.
    """
    verified_auth = webauthn.verify_authentication_response(
        credential=credential_data,
        expected_challenge=expected_challenge_bytes,
        expected_rp_id=Config.RP_ID,
        expected_origin=Config.ORIGIN,
        credential_public_key=public_key_bytes,
        credential_current_sign_count=current_sign_count,
        require_user_verification=True
    )
    return verified_auth

