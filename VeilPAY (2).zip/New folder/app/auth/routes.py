import json
import time
import datetime
import logging
from flask import Blueprint, request, jsonify, session
import webauthn
from webauthn.helpers import bytes_to_base64url, base64url_to_bytes
from bson import ObjectId

from app.db import get_db
from app.config import Config
from app.security import (
    encrypt_field,
    decrypt_field,
    require_csrf,
    require_login,
    rate_limit
)
from app.users.alias import create_unique_alias
from app.auth.webauthn_service import (
    store_challenge,
    get_and_consume_challenge,
    generate_registration_options_for_user,
    verify_registration,
    generate_authentication_options_for_user,
    verify_authentication
)

logger = logging.getLogger(__name__)
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

@auth_bp.route('/register/begin', methods=['POST'])
@rate_limit(limit_count=20, window_seconds=60)
def register_begin():
    """
    Step 1 of registration:
    Returns WebAuthn creation options with userVerification: 'required'
    and residentKey: 'preferred' (Section 9).
    """
    data = request.get_json() or {}
    email = data.get('email', '').strip().lower()
    payout_email = data.get('payout_email', '').strip().lower() or email

    if not email or '@' not in email:
        return jsonify({"error": "A valid email address is required for platform account setup."}), 400

    db = get_db()
    
    try:
        options, challenge_bytes = generate_registration_options_for_user(email)
        challenge_id = store_challenge(
            db,
            user_or_session_id=session.get('_csrf_token', 'anon'),
            purpose='register',
            challenge_bytes=challenge_bytes,
            ttl_seconds=300
        )
        
        session['reg_challenge_id'] = challenge_id
        session['reg_email'] = email
        session['reg_payout_email'] = payout_email

        return webauthn.options_to_json(options), 200, {'Content-Type': 'application/json'}
    except Exception as e:
        logger.error("Error generating registration options: %s", e)
        return jsonify({"error": f"Failed to begin registration: {str(e)}"}), 500

@auth_bp.route('/register/finish', methods=['POST'])
@rate_limit(limit_count=20, window_seconds=60)
@require_csrf
def register_finish():
    """
    Step 2 of registration:
    Verifies passkey creation with py_webauthn, stores credential,
    creates user with random alias, and establishes session (Section 9).
    """
    data = request.get_json() or {}
    credential_payload = data.get('credential')
    label = data.get('label', 'Primary Passkey').strip()

    if not credential_payload:
        return jsonify({"error": "Missing WebAuthn credential payload"}), 400

    challenge_id = session.pop('reg_challenge_id', None) or data.get('challenge_id')
    email = session.pop('reg_email', None)
    payout_email = session.pop('reg_payout_email', None) or email

    if not challenge_id or not email:
        return jsonify({"error": "Registration session expired or invalid. Please try again."}), 400

    db = get_db()
    expected_challenge = get_and_consume_challenge(db, challenge_id, expected_purpose='register')
    if not expected_challenge:
        return jsonify({"error": "Challenge expired or already used. Please restart registration."}), 400

    try:
        verified_reg = verify_registration(credential_payload, expected_challenge)
    except Exception as e:
        logger.warning("Passkey registration verification failed: %s", e)
        return jsonify({"error": f"Passkey verification failed: {str(e)}"}), 400

    cred_id_b64 = bytes_to_base64url(verified_reg.credential_id)

    # Check if credential already exists
    if db.credentials.find_one({"credential_id": cred_id_b64}):
        return jsonify({"error": "This passkey credential is already registered."}), 400

    alias = create_unique_alias(db)

    raw_display_name = str(data.get('display_name', '')).strip()
    if raw_display_name:
        from app.risk.pii import scrub_pii_regex
        cleaned_name, _, _ = scrub_pii_regex(raw_display_name)
        display_name = cleaned_name[:30]
    else:
        display_name = ""

    # 1. Create User document (Section 7)
    user_doc = {
        "alias": alias,
        "display_name": display_name,
        "contact_email_enc": encrypt_field(email),
        "payout_email_enc": encrypt_field(payout_email),
        "limits": {
            "per_payment": "200.00",
            "per_day": "500.00",
            "per_payee_default": "100.00"
        },
        "new_payee_cooling_hours": 24,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
        "status": "active"
    }
    user_res = db.users.insert_one(user_doc)
    user_id = user_res.inserted_id

    # 2. Store Credential document (Section 7)
    cred_doc = {
        "user_id": user_id,
        "credential_id": cred_id_b64,
        "public_key": verified_reg.credential_public_key,
        "sign_count": verified_reg.sign_count,
        "transports": data.get("transports", []),
        "label": label,
        "created_at": datetime.datetime.now(datetime.timezone.utc),
        "last_used_at": datetime.datetime.now(datetime.timezone.utc)
    }
    db.credentials.insert_one(cred_doc)

    # 3. Establish session
    csrf_tok = session.get('_csrf_token')
    session.clear()
    if csrf_tok:
        session['_csrf_token'] = csrf_tok
    session['user_id'] = str(user_id)
    session['alias'] = alias
    session['last_active'] = time.time()

    return jsonify({
        "status": "ok",
        "alias": alias,
        "user_id": str(user_id),
        "message": "Passkey registered successfully! Welcome to VeilPay."
    }), 201

@auth_bp.route('/login/begin', methods=['POST'])
@rate_limit(limit_count=20, window_seconds=60)
def login_begin():
    """
    Step 1 of login:
    Returns WebAuthn request options. Supports resident keys or specific alias.
    """
    data = request.get_json() or {}
    alias = data.get('alias', '').strip().lower()
    
    db = get_db()
    allowed_credentials = None

    if alias:
        user = db.users.find_one({"alias": alias})
        if not user:
            return jsonify({"error": "No account found matching this alias."}), 404
        allowed_credentials = list(db.credentials.find({"user_id": user["_id"]}))

    try:
        options, challenge_bytes = generate_authentication_options_for_user(allowed_credentials)
        challenge_id = store_challenge(
            db,
            user_or_session_id=session.get('_csrf_token', 'anon'),
            purpose='login',
            challenge_bytes=challenge_bytes,
            ttl_seconds=300
        )
        session['login_challenge_id'] = challenge_id

        return webauthn.options_to_json(options), 200, {'Content-Type': 'application/json'}
    except Exception as e:
        logger.error("Error generating login options: %s", e)
        return jsonify({"error": f"Failed to begin login: {str(e)}"}), 500

@auth_bp.route('/login/finish', methods=['POST'])
@rate_limit(limit_count=20, window_seconds=60)
@require_csrf
def login_finish():
    """
    Step 2 of login:
    Verifies passkey assertion with py_webauthn, updates sign count,
    sets 30-minute idle session (Section 9).
    """
    data = request.get_json() or {}
    credential_payload = data.get('credential')

    if not credential_payload:
        return jsonify({"error": "Missing WebAuthn credential payload"}), 400

    challenge_id = session.pop('login_challenge_id', None) or data.get('challenge_id')
    if not challenge_id:
        return jsonify({"error": "Login challenge missing or expired. Please retry."}), 400

    db = get_db()
    expected_challenge = get_and_consume_challenge(db, challenge_id, expected_purpose='login')
    if not expected_challenge:
        return jsonify({"error": "Challenge expired or already consumed."}), 400

    # Look up credential by raw credential id
    cred_id = credential_payload.get('id')
    cred_doc = db.credentials.find_one({"credential_id": cred_id})
    if not cred_doc:
        return jsonify({"error": "Unrecognized passkey credential."}), 401

    user_doc = db.users.find_one({"_id": cred_doc["user_id"]})
    if not user_doc or user_doc.get("status") != "active":
        return jsonify({"error": "Account is inactive or not found."}), 403

    try:
        verified_auth = verify_authentication(
            credential_data=credential_payload,
            expected_challenge_bytes=expected_challenge,
            public_key_bytes=cred_doc["public_key"],
            current_sign_count=cred_doc.get("sign_count", 0)
        )
    except Exception as e:
        logger.warning("Passkey authentication failed: %s", e)
        return jsonify({"error": f"Authentication failed: {str(e)}"}), 401

    # Update sign count and last used timestamp
    db.credentials.update_one(
        {"_id": cred_doc["_id"]},
        {
            "$set": {
                "sign_count": verified_auth.new_sign_count,
                "last_used_at": datetime.datetime.now(datetime.timezone.utc)
            }
        }
    )

    # Establish session
    csrf_tok = session.get('_csrf_token')
    session.clear()
    if csrf_tok:
        session['_csrf_token'] = csrf_tok
    session['user_id'] = str(user_doc['_id'])
    session['alias'] = user_doc['alias']
    session['last_active'] = time.time()

    return jsonify({
        "status": "ok",
        "alias": user_doc['alias'],
        "user_id": str(user_doc['_id']),
        "message": f"Welcome back, {user_doc['alias']}!"
    }), 200

@auth_bp.route('/logout', methods=['POST'])
@require_csrf
def logout():
    """Ends user session."""
    csrf_tok = session.get('_csrf_token')
    session.clear()
    if csrf_tok:
        session['_csrf_token'] = csrf_tok
    return jsonify({"status": "ok", "message": "Successfully logged out."}), 200

