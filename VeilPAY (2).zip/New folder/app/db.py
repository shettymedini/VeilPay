import logging
from pymongo import MongoClient, ASCENDING
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
import mongomock

logger = logging.getLogger(__name__)

_mongo_client = None
_db_instance = None
_is_mock = False

def get_db(uri=None, db_name="veilpay", force_mock=False):
    """
    Returns the database instance.
    Uses MongoDB Atlas via MONGODB_URI if available, or falls back to mongomock for test mode.
    """
    global _mongo_client, _db_instance, _is_mock
    
    if _db_instance is not None and not force_mock:
        return _db_instance
        
    if force_mock:
        logger.info("Using mongomock for database instance.")
        _mongo_client = mongomock.MongoClient()
        _db_instance = _mongo_client[db_name]
        _is_mock = True
        init_indexes(_db_instance)
        return _db_instance

    if not uri:
        from app.config import Config
        uri = Config.MONGODB_URI

    if uri:
        try:
            logger.info("Connecting to MongoDB...")
            client = MongoClient(uri, serverSelectionTimeoutMS=4000)
            # Ping database to verify connection
            client.admin.command('ping')
            _mongo_client = client
            try:
                default_db = client.get_default_database()
                default_name = default_db.name if default_db is not None else db_name
            except Exception:
                default_name = db_name
            _db_instance = client[default_name]
            _is_mock = False
            logger.info("Connected to MongoDB successfully.")
            init_indexes(_db_instance)
            return _db_instance
        except (ConnectionFailure, ServerSelectionTimeoutError, Exception) as e:
            logger.warning("Failed to connect to MongoDB Atlas (%s). Falling back to in-memory mock.", e)
            _mongo_client = mongomock.MongoClient()
            _db_instance = _mongo_client[db_name]
            _is_mock = True
            init_indexes(_db_instance)
            return _db_instance
    else:
        logger.info("No MONGODB_URI provided. Initializing mongomock.")
        _mongo_client = mongomock.MongoClient()
        _db_instance = _mongo_client[db_name]
        _is_mock = True
        init_indexes(_db_instance)
        return _db_instance

def is_mock_db():
    return _is_mock

def init_indexes(db):
    """
    Initializes required collections and indexes according to Section 7.
    """
    try:
        # users: alias (unique)
        db.users.create_index([("alias", ASCENDING)], unique=True)
        
        # credentials: credential_id (unique), user_id
        db.credentials.create_index([("credential_id", ASCENDING)], unique=True)
        db.credentials.create_index([("user_id", ASCENDING)])
        
        # contacts: compound unique (owner_id, alias)
        db.contacts.create_index([("owner_id", ASCENDING), ("alias", ASCENDING)], unique=True)
        
        # payment_intents: payer_id, payee_id, status, expires_at, hold_until
        db.payment_intents.create_index([("payer_id", ASCENDING)])
        db.payment_intents.create_index([("payee_id", ASCENDING)])
        db.payment_intents.create_index([("status", ASCENDING)])
        db.payment_intents.create_index([("expires_at", ASCENDING)])
        
        # ledger: seq (unique), intent_id
        db.ledger.create_index([("seq", ASCENDING)], unique=True)
        db.ledger.create_index([("intent_id", ASCENDING)])
        
        # webauthn_challenges: TTL index on expires_at
        db.webauthn_challenges.create_index([("expires_at", ASCENDING)], expireAfterSeconds=0)
        logger.info("Database indexes successfully initialized.")
    except Exception as e:
        logger.warning("Index initialization notice: %s", e)

def check_db():
    """
    Checks database health and returns status dictionary.
    """
    global _mongo_client, _is_mock
    if _db_instance is None:
        get_db()
    if _is_mock:
        return {"status": "ok", "mode": "in-memory (mongomock)", "connected": True}
    try:
        _mongo_client.admin.command('ping')
        return {"status": "ok", "mode": "MongoDB Atlas", "connected": True}
    except Exception as e:
        return {"status": "error", "error": str(e), "connected": False}

