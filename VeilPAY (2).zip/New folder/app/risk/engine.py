import datetime
import statistics
from decimal import Decimal
from bson import ObjectId

PRESSURE_KEYWORDS = [
    "urgent", "immediately", "gift card", "verify account", "lottery",
    "wire", "crypto", "irs", "emergency", "police"
]

def get_risk_tier(score: int) -> str:
    """Tiers: 0 to 29 LOW, 30 to 59 MEDIUM, 60 and above HIGH (Section 11)."""
    if score < 30:
        return "LOW"
    elif score < 60:
        return "MEDIUM"
    else:
        return "HIGH"

def evaluate_risk(
    db,
    payer_doc: dict,
    payee_doc: dict,
    amount_dec: Decimal,
    raw_memo: str = "",
    memo_flags: list = None
) -> dict:
    """
    Evaluates deterministic risk rules and hard limits (Section 11).
    Returns risk dictionary: {score, tier, reasons, explanation, is_blocked, block_reason}.
    """
    payer_id = payer_doc["_id"]
    payee_id = payee_doc["_id"]
    payee_alias = payee_doc["alias"]
    memo_flags = memo_flags or []

    # 1. HARD RULES (Immediate Block, no override)
    limits = payer_doc.get("limits", {})
    per_payment_limit = Decimal(limits.get("per_payment", "200.00"))
    per_day_limit = Decimal(limits.get("per_day", "500.00"))

    # Check contact specific limit
    contact = db.contacts.find_one({"owner_id": payer_id, "alias": payee_alias})
    if contact and contact.get("per_payee_limit"):
        per_payee_limit = Decimal(contact["per_payee_limit"])
    else:
        per_payee_limit = Decimal(limits.get("per_payee_default", "100.00"))

    if amount_dec > per_payment_limit:
        return {
            "is_blocked": True,
            "block_reason": f"Amount ${amount_dec:.2f} exceeds your per-payment limit of ${per_payment_limit:.2f}.",
            "score": 100,
            "tier": "HIGH",
            "reasons": ["Exceeds per-payment limit"],
            "explanation": "Payment blocked: amount exceeds your configured per-payment limit."
        }

    if amount_dec > per_payee_limit:
        return {
            "is_blocked": True,
            "block_reason": f"Amount ${amount_dec:.2f} exceeds your per-payee limit of ${per_payee_limit:.2f} for payee {payee_alias}.",
            "score": 100,
            "tier": "HIGH",
            "reasons": ["Exceeds per-payee limit"],
            "explanation": "Payment blocked: amount exceeds the limit configured for this payee."
        }

    # Daily total check: sum today's completed, captured, or pending payments
    now = datetime.datetime.now(datetime.timezone.utc)
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_intents = list(db.payment_intents.find({
        "payer_id": payer_id,
        "created_at": {"$gte": day_start},
        "status": {"$in": ["AWAITING_SIGNATURE", "AWAITING_PAYPAL_APPROVAL", "AUTHORIZED_HOLD", "CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    }))
    
    daily_total = sum(Decimal(str(i["amount"])) for i in today_intents)
    if daily_total + amount_dec > per_day_limit:
        return {
            "is_blocked": True,
            "block_reason": f"Payment would bring daily total to ${(daily_total + amount_dec):.2f}, exceeding your daily limit of ${per_day_limit:.2f}.",
            "score": 100,
            "tier": "HIGH",
            "reasons": ["Exceeds daily spending limit"],
            "explanation": "Payment blocked: transaction would exceed your 24-hour spending limit."
        }

    # 2. DETERMINISTIC SCORING RULES
    score = 0
    reasons = []

    # Rule: First payment to this payee (+25) or Repeat Payee recognition
    prior_payments_count = db.payment_intents.count_documents({
        "payer_id": payer_id,
        "payee_id": payee_id,
        "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    })
    if prior_payments_count == 0:
        score += 25
        reasons.append("First payment to this payee (+25)")
    else:
        reasons.append(f"Repeat payee ({prior_payments_count} prior payment{'s' if prior_payments_count > 1 else ''})")

    # Rule: Payee added less than cooling period ago and amount above $50.00 (+20)
    cooling_hours = payer_doc.get("new_payee_cooling_hours", 24)
    if contact and contact.get("created_at"):
        contact_created = contact["created_at"]
        if contact_created.tzinfo is None:
            contact_created = contact_created.replace(tzinfo=datetime.timezone.utc)
        age_hours = (now - contact_created).total_seconds() / 3600.0
        if age_hours < cooling_hours and amount_dec > Decimal("50.00"):
            score += 20
            reasons.append(f"Payee added < {cooling_hours}h ago and amount > $50 (+20)")

    # Rule: Median comparison (last 10 payments)
    recent_intents = list(db.payment_intents.find({
        "payer_id": payer_id,
        "status": {"$in": ["CAPTURED", "PAYOUT_SENT", "COMPLETED"]}
    }).sort("created_at", -1).limit(10))

    if recent_intents:
        past_amounts = [float(Decimal(str(i["amount"]))) for i in recent_intents]
        median_val = Decimal(str(round(statistics.median(past_amounts), 2)))
        if median_val > 0:
            ratio = amount_dec / median_val
            if ratio > Decimal("10.0"):
                score += 35
                reasons.append(f"Amount is > 10x median payment (${median_val}) (+35)")
            elif ratio > Decimal("3.0"):
                score += 20
                reasons.append(f"Amount is > 3x median payment (${median_val}) (+20)")

    # Rule: 3 or more payments in 10 minutes (+20)
    ten_min_ago = now - datetime.timedelta(minutes=10)
    recent_velocity = db.payment_intents.count_documents({
        "payer_id": payer_id,
        "created_at": {"$gte": ten_min_ago}
    })
    if recent_velocity >= 3:
        score += 20
        reasons.append("3 or more payments initiated in past 10 minutes (+20)")

    # Rule: Local time between 00:00 and 05:00 (+10)
    if 0 <= now.hour < 5:
        score += 10
        reasons.append("Transaction initiated during night hours (00:00-05:00) (+10)")

    # Rule: Memo contains pressure keywords (+15)
    memo_lower = (raw_memo or "").lower()
    for kw in PRESSURE_KEYWORDS:
        if kw in memo_lower:
            score += 15
            reasons.append(f"Note contains urgency keyword '{kw}' (+15)")
            break

    # Rule: Memo contained personal details that were scrubbed (+10)
    if memo_flags:
        score += 10
        reasons.append("Contact details detected and scrubbed from note (+10)")

    # Base deterministic score (capped at 100)
    rule_score = min(score, 100)
    base_tier = get_risk_tier(rule_score)

    # 3. LLM ENRICHMENT LAYER (Section 11)
    # The LLM never approves/denies; it writes plain-language explanation and can only raise risk
    explanation = None
    extra_risk = 0
    scam_pattern = None

    try:
        from app.risk.llm import generate_risk_explanation
        explanation, extra_risk, scam_pattern = generate_risk_explanation(
            rule_score=rule_score,
            tier=base_tier,
            reasons=reasons,
            masked_memo=raw_memo,
            amount_str=f"{amount_dec:.2f}",
            payer_alias=payer_doc["alias"],
            payee_alias=payee_alias,
            prior_payments_count=prior_payments_count,
            is_contact=contact is not None
        )
    except Exception:
        pass

    # Ensure extra_risk is non-negative (Rule 3: LLM can never lower risk)
    extra_risk = max(0, int(extra_risk))
    if extra_risk > 0 and scam_pattern:
        reasons.append(f"AI security note: {scam_pattern} (+{extra_risk})")

    final_score = min(rule_score + extra_risk, 100)
    final_tier = get_risk_tier(final_score)

    # Fallback explanation if none was generated
    if not explanation:
        if prior_payments_count >= 1 and contact is None:
            explanation = f"You have paid this person {prior_payments_count} time(s). Verified passkey transfer."
        elif final_tier == "LOW":
            explanation = "Standard payment activity. Protected by passkey signature and hold window."
        elif final_tier == "MEDIUM":
            if any("First payment" in r for r in reasons):
                explanation = "First payment to this person, so we added a safety hold."
            else:
                explanation = "Unusual activity detected (e.g., new payee or larger amount); 5-minute safety hold applied."
        else:
            explanation = "High risk detected. Payment requires extra confirmation or is restricted."

    return {
        "is_blocked": False,
        "block_reason": None,
        "score": final_score,
        "tier": final_tier,
        "rule_score": rule_score,
        "extra_risk": extra_risk,
        "scam_pattern": scam_pattern,
        "reasons": reasons,
        "explanation": explanation,
        "prior_payments_count": prior_payments_count,
        "is_contact": contact is not None,
        "suggest_save_contact": (contact is None and prior_payments_count >= 1)
    }

