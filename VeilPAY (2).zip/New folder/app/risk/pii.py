import re

# Comprehensive regex patterns for PII scrubbing (Section 12)
EMAIL_PATTERN = re.compile(
    r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
    re.IGNORECASE
)

# Standard and Indian UPI ID formats: name@bank, name@upi, name@okhdfcbank, etc.
UPI_PATTERN = re.compile(
    r'\b[a-zA-Z0-9._-]{2,40}@(ok[a-zA-Z]+|[a-zA-Z]{2,20})\b',
    re.IGNORECASE
)

# URLs
URL_PATTERN = re.compile(
    r'https?://[^\s]+|www\.[^\s]+',
    re.IGNORECASE
)

# International and Indian phone numbers (+91, 10-12 digits with separators, etc.)
PHONE_PATTERN = re.compile(
    r'(\+?\d{1,4}[-.\s]?)?(\(?\d{2,5}\)?[-.\s]?)?\d{3,5}[-.\s]?\d{3,5}\b'
)

# Runs of 8 or more digits (account numbers, cards, phone runs)
DIGIT_RUN_PATTERN = re.compile(
    r'\b(?:\d[-.\s]?){8,}\b'
)

def scrub_pii_regex(text: str) -> tuple[str, bool, list[str]]:
    """
    Pass 1 Regex PII scrubber.
    Masks emails, phone numbers, UPI handles, URLs, and long digit runs with [hidden].
    Returns (masked_text, found_bool, flags_list).
    """
    if not text or not isinstance(text, str):
        return "", False, []

    flags = []
    masked = text

    # 1. URLs
    if URL_PATTERN.search(masked):
        flags.append("url_detected")
        masked = URL_PATTERN.sub("[hidden]", masked)

    # 2. Emails
    if EMAIL_PATTERN.search(masked):
        flags.append("email_detected")
        masked = EMAIL_PATTERN.sub("[hidden]", masked)

    # 3. UPI IDs (handles that were not already emails)
    if UPI_PATTERN.search(masked):
        flags.append("upi_detected")
        masked = UPI_PATTERN.sub("[hidden]", masked)

    # 4. Long digit sequences (8+ digits)
    if DIGIT_RUN_PATTERN.search(masked):
        flags.append("digit_run_detected")
        masked = DIGIT_RUN_PATTERN.sub("[hidden]", masked)

    # 5. General phone numbers
    def replace_phone(match):
        val = match.group(0)
        # Only mask if it contains at least 7 digits to avoid masking small numbers
        digits = re.sub(r'\D', '', val)
        if len(digits) >= 7:
            return "[hidden]"
        return val

    new_masked = PHONE_PATTERN.sub(replace_phone, masked)
    if new_masked != masked:
        if "phone_detected" not in flags and "digit_run_detected" not in flags:
            flags.append("phone_detected")
        masked = new_masked

    found = len(flags) > 0
    return masked, found, flags

def scrub_pii(text: str, enable_llm: bool = True) -> tuple[str, bool, list[str]]:
    """
    Two-pass PII Scrubber (Section 12):
    Pass 1: Regex pass (phones, emails, UPI IDs, URLs, long digit runs).
    Pass 2: LLM pass (catches obfuscations like 'nine eight seven...' or 'name at domain dot com').
    Returns (final_masked_text, found_bool, flags_list).
    """
    masked, found, flags = scrub_pii_regex(text)

    if enable_llm and text:
        try:
            from app.risk.llm import scrub_pii_llm
            llm_masked, llm_found = scrub_pii_llm(masked)
            if llm_found and llm_masked != masked:
                masked = llm_masked
                found = True
                if "obfuscated_pii_detected" not in flags:
                    flags.append("obfuscated_pii_detected")
        except Exception:
            pass  # Fall back to regex result

    return masked, found, flags

